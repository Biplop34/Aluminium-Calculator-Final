import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // CORS middleware to support mobile app (Capacitor) requests
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
    } else {
      res.setHeader("Access-Control-Allow-Origin", "*");
    }
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
    res.setHeader("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Authorization");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // Set payload limit higher to handle base64 image uploads comfortably
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Lazy initialize Gemini AI client
  let ai: GoogleGenAI | null = null;
  const getAiClient = () => {
    if (!ai) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY environment variable is not defined.");
      }
      ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return ai;
  };

  // API Route for Hand-written Image scan via Gemini
  app.post("/api/scan", async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        return res.status(400).json({ error: "No image data provided" });
      }

      // Check format (e.g. data:image/png;base64,...)
      const match = image.match(/^data:(image\/\w+);base64,(.+)$/);
      if (!match) {
        return res.status(400).json({ error: "Invalid image format. Expected a base64 Data URL." });
      }

      const mimeType = match[1];
      const base64Data = match[2];

      const client = getAiClient();

      const prompt = `You are a professional, high-precision handwritten note reader for Thai window fabrication.
Look at the handwritten image and extract all the measurement rows in order.

CRITICAL MEASUREMENT RULES:
1. Each line is structured as: [ID/Serial] [Height] x [Length 1] / [Length 2]
   - The symbol 'x', 'X', '×', or '*' separates the Height and Length.
   - The slash '/' separates Length 1 and Length 2 (Length 2 is optional and only present if there is a '/').
   - Dashes '-' inside any number represent a DECIMAL POINT '.'. For example:
     * '177-1' must be extracted as '177.1'
     * '165-2' must be extracted as '165.2'
     * '197-5' must be extracted as '197.5'
     * '197-6' must be extracted as '197.6'
     * '43-3' must be extracted as '43.3'
   - Slashes '/' are ONLY used to separate Length 1 and Length 2. Do NOT treat slashes as decimal points when they divide two numbers! For example:
     * '165-2 / 167' means Length 1 is '165.2' and Length 2 is '167'
     * '212 / 211-5' means Length 1 is '212' and Length 2 is '211.5'
     * '43 / 43-3' means Length 1 is '43' and Length 2 is '43.3'
   - If a number has no dash or slash, keep it as an integer/decimal (e.g., '212' is '212', '198' is '198').

EXAMPLES:
- "① 177-1 x 165-2 / 167" -> height: "177.1", length1: "165.2", length2: "167"
- "② 197-5 x 212" -> height: "197.5", length1: "212", length2: ""
- "③ 197-6 x 212 / 211-5" -> height: "197.6", length1: "212", length2: "211.5"
- "⑦ 36 x 43 / 43-3" -> height: "36", length1: "43", length2: "43.3"

CRITICAL COMPLETENESS REQUIREMENT:
You MUST transcribe and extract EVERY SINGLE handwritten item on the page from top to bottom.
Do NOT skip any items, do NOT stop transcribing, do NOT truncate, and do NOT limit yourself.
Output the extracted items in the exact order found.`;

      // Helper for robust plain-text measurements parser
      const parsePlainTextMeasurements = (text: string): { items: any[] } => {
        const lines = text.split(/\r?\n/);
        const items: any[] = [];
        let itemIndex = 1;

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;

          // Check if line contains an 'x' or 'X' or '×' or '*' symbol
          if (!/[xX×*]/.test(trimmed)) continue;

          // Try to extract serial number/id if present
          let id = itemIndex;
          const leadMatch = trimmed.match(/^([①-⑳\d]+|\(\d+\)|\[\d+\]|[a-zA-Z]\d+)\s*[:.\-)]?\s*/);
          let lineRest = trimmed;
          if (leadMatch) {
            const rawId = leadMatch[1];
            lineRest = trimmed.slice(leadMatch[0].length).trim();
            
            const circledMap: { [key: string]: number } = {
              '①': 1, '②': 2, 'pattern3': 3, '③': 3, '④': 4, '⑤': 5, '⑥': 6, '⑦': 7, '⑧': 8, '⑨': 9, '⑩': 10,
              '⑪': 11, '⑫': 12, '⑬': 13, '⑭': 14, '⑮': 15, '⑯': 16, '⑰': 17, '⑱': 18, '⑲': 19, '⑳': 20
            };
            
            if (circledMap[rawId] !== undefined) {
              id = circledMap[rawId];
            } else {
              const parsedId = parseInt(rawId.replace(/[^\d]/g, ''), 10);
              if (!isNaN(parsedId)) {
                id = parsedId;
              }
            }
          }

          // Split into height and lengths parts
          const parts = lineRest.split(/[xX×*]/);
          if (parts.length < 2) continue;

          const rawHeight = parts[0].trim();
          const rawLengths = parts.slice(1).join('x').trim();

          // Scan result cleaning helper:
          // - Dashes '-' represent decimal points
          // - Only keep digits and dots
          const cleanScanNum = (val: string): string => {
            if (!val) return "";
            let cleaned = val.trim();
            cleaned = cleaned.replace(/-/g, '.');
            cleaned = cleaned.replace(/\s*\.\s*/g, '.');
            cleaned = cleaned.replace(/\.+/g, '.');
            cleaned = cleaned.replace(/[^\d.]/g, '');
            return cleaned;
          };

          const height = cleanScanNum(rawHeight);

          let rawL1 = rawLengths;
          let rawL2 = '';

          const lengthParts = rawLengths.split('/');
          if (lengthParts.length > 1) {
            rawL1 = lengthParts[0].trim();
            rawL2 = lengthParts[1].trim();
          } else {
            const wordMatch = rawLengths.match(/\s+(over|under|by|divided\s+by)\s+/i);
            if (wordMatch) {
              const idx = rawLengths.indexOf(wordMatch[0]);
              rawL1 = rawLengths.substring(0, idx).trim();
              rawL2 = rawLengths.substring(idx + wordMatch[0].length).trim();
            }
          }

          const length1 = cleanScanNum(rawL1);
          const length2 = cleanScanNum(rawL2);

          if (height || length1) {
            items.push({
              id,
              height,
              length1,
              length2: length2 || ''
            });
            itemIndex++;
          }
        }

        return { items };
      };

      // Normalization helper that can handle JSON or plain text
      const normalizeScanningResult = (data: any): { items: any[] } => {
        if (!data) return { items: [] };

        let parsedJson: any = null;
        if (typeof data === "string") {
          const cleanText = data.trim();
          if (cleanText.startsWith("{") || cleanText.startsWith("[")) {
            try {
              parsedJson = JSON.parse(cleanText);
            } catch (e) {
              console.warn("Failed to parse string as JSON", e);
            }
          }

          if (!parsedJson) {
            let textToParse = cleanText;
            if (textToParse.startsWith("```")) {
              textToParse = textToParse.replace(/^```(?:json|text|plain)?/i, "").replace(/```$/, "").trim();
            }
            if (textToParse.startsWith("{") || textToParse.startsWith("[")) {
              try {
                parsedJson = JSON.parse(textToParse);
              } catch (e) {
                // Ignore
              }
            }
            
            if (!parsedJson) {
              return parsePlainTextMeasurements(textToParse);
            }
          }
        } else {
          parsedJson = data;
        }

        if (parsedJson) {
          let rawItems: any[] = [];
          if (Array.isArray(parsedJson)) {
            rawItems = parsedJson;
          } else if (typeof parsedJson === "object") {
            if (parsedJson.items && Array.isArray(parsedJson.items)) {
              rawItems = parsedJson.items;
            } else {
              const arrayKey = Object.keys(parsedJson).find((key) => Array.isArray(parsedJson[key]));
              if (arrayKey) {
                rawItems = parsedJson[arrayKey];
              } else if (parsedJson.height || parsedJson.length1) {
                rawItems = [parsedJson];
              }
            }
          }

          if (rawItems.length > 0) {
            const items = rawItems
              .map((item, index) => {
                if (!item || typeof item !== "object") return null;

                let id = index + 1;
                if (typeof item.id === "number") {
                  id = item.id;
                } else if (item.id !== undefined && item.id !== null) {
                  const parsedId = parseInt(String(item.id), 10);
                  if (!isNaN(parsedId)) id = parsedId;
                }

                let height = "";
                const heightKeys = ["height", "h", "hight", "Height"];
                for (const k of heightKeys) {
                  if (item[k] !== undefined && item[k] !== null) {
                    height = String(item[k]).trim();
                    break;
                  }
                }

                let length1 = "";
                let length2 = "";

                const l1Keys = ["length1", "length_1", "l1", "length", "len1", "Length1"];
                for (const k of l1Keys) {
                  if (item[k] !== undefined && item[k] !== null) {
                    length1 = String(item[k]).trim();
                    break;
                  }
                }

                const l2Keys = ["length2", "length_2", "l2", "len2", "Length2"];
                for (const k of l2Keys) {
                  if (item[k] !== undefined && item[k] !== null) {
                    length2 = String(item[k]).trim();
                    break;
                  }
                }

                if (!length1) {
                  const remainingKeys = Object.keys(item).filter(
                    (k) => !["id", "height", "h", "hight", "Height"].includes(k)
                  );
                  if (remainingKeys.length > 0) {
                    length1 = String(item[remainingKeys[0]]).trim();
                    if (remainingKeys.length > 1) {
                      length2 = String(item[remainingKeys[1]]).trim();
                    }
                  }
                }

                // If length1 contains a slash '/' (fraction), split it!
                if (length1.includes('/')) {
                  const lparts = length1.split('/');
                  length1 = lparts[0].trim();
                  length2 = lparts[1].trim();
                }

                // Scan result cleaning helper:
                // - Dashes '-' represent decimal points
                // - Only keep digits and dots
                const cleanScanNum = (val: string): string => {
                  if (!val) return "";
                  let cleaned = val.trim();
                  cleaned = cleaned.replace(/-/g, '.');
                  cleaned = cleaned.replace(/\s*\.\s*/g, '.');
                  cleaned = cleaned.replace(/\.+/g, '.');
                  cleaned = cleaned.replace(/[^\d.]/g, '');
                  return cleaned;
                };

                return {
                  id,
                  height: cleanScanNum(height),
                  length1: cleanScanNum(length1),
                  length2: cleanScanNum(length2),
                };
              })
              .filter(Boolean);

            if (items.length > 0) {
              return { items };
            }
          }
        }

        if (typeof data === "string") {
          return parsePlainTextMeasurements(data);
        }

        return { items: [] };
      };

      const modelCandidates = ["gemini-3.6-flash", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"];
      let lastError: any = null;
      let responseText = "";

      console.log("--- STARTING MULTI-MODE DEEP HYBRID SCAN (METHOD 1: JSON MODE) ---");
      for (const modelName of modelCandidates) {
        try {
          console.log(`[Method 1] Attempting structured JSON scan with model: ${modelName}`);
          const response = await client.models.generateContent({
            model: modelName,
            contents: [
              {
                role: "user",
                parts: [
                  { text: prompt },
                  { inlineData: { mimeType, data: base64Data } }
                ]
              }
            ],
            config: {
              responseMimeType: "application/json",
              maxOutputTokens: 8192,
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  items: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.NUMBER, description: "Item serial number index" },
                        height: { type: Type.STRING, description: "Parsed height, e.g. '21.2'" },
                        length1: { type: Type.STRING, description: "Parsed length 1, e.g. '46.0'" },
                        length2: { type: Type.STRING, description: "Parsed length 2 (optional), e.g. '45.5' or empty/null" }
                      },
                      required: ["id", "height", "length1"]
                    }
                  }
                },
                required: ["items"]
              }
            }
          });

          if (response && response.text && response.text.trim().length > 0) {
            // Quick check if the response parses cleanly as JSON and contains elements
            const checkParsed = JSON.parse(response.text.trim());
            const normalizedResult = normalizeScanningResult(checkParsed);
            if (normalizedResult && normalizedResult.items && normalizedResult.items.length > 0) {
              responseText = response.text;
              console.log(`[Method 1] Successfully scanned & validated in JSON Mode using ${modelName}`);
              break;
            }
          }
        } catch (err: any) {
          console.warn(`[Method 1] Model ${modelName} JSON scan failed/busy:`, err.message || err);
          lastError = err;
        }
      }

      // If Method 1 fails, immediately fallback to Method 2: Plain Text Transcribing + High-precision string parsing
      if (!responseText) {
        console.log("--- FALLING BACK TO METHOD 2: PLAIN TEXT STRIP TRANSCRIPTION + REGEX PARSING ---");
        const plainTextPrompt = `You are a professional, high-precision handwritten note reader.
Look at the handwritten image, find all lines of measurements, and transcribe them.
You MUST write each row in this exact format:
id: height x length1 / length2

Examples:
1: 177-1 x 165-2 / 167
2: 197-5 x 212
3: 197-6 x 212 / 211-5

Only output the plain list, one item per line. Do not include any other markdown text, headers, explanations or summaries.
IMPORTANT THAI MEASUREMENT FORMAT RULES:
Keep any slashes "/" and dashes "-" as they are written (e.g. 177-1, 165-2).
Transcribe EVERY SINGLE row of measurement from top to bottom. Ensure no lines are skipped!`;

        for (const modelName of modelCandidates) {
          try {
            console.log(`[Method 2] Attempting Plain Text transcription with model: ${modelName}`);
            const response = await client.models.generateContent({
              model: modelName,
              contents: [
                {
                  role: "user",
                  parts: [
                    { text: plainTextPrompt },
                    { inlineData: { mimeType, data: base64Data } }
                  ]
                }
              ]
            });

            if (response && response.text && response.text.trim().length > 0) {
              responseText = response.text;
              console.log(`[Method 2] Successfully transcribed in Plain Text Mode using ${modelName}`);
              break;
            }
          } catch (err: any) {
            console.warn(`[Method 2] Model ${modelName} Plain Text scan failed:`, err.message || err);
            lastError = err;
          }
        }
      }

      if (!responseText) {
        throw new Error(lastError ? lastError.message || JSON.stringify(lastError) : "All candidate models and modes failed to respond.");
      }

      const result = normalizeScanningResult(responseText);
      if (!result || !result.items || result.items.length === 0) {
        throw new Error("Failed to scan: No valid measurement rows could be extracted from this image.");
      }

      console.log(`Successfully completed scan with ${result.items.length} items parsed.`);
      res.json(result);
    } catch (err: any) {
      console.error("Scanning Error:", err);
      res.status(500).json({ error: err.message || "Failed to parse handwriting image." });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite middleware mounted for development");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static files from dist in production");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
