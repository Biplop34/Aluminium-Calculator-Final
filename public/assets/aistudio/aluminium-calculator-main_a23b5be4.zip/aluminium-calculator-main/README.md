<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/5dabf07d-ec26-48c3-bcfd-940745b5ba86

## Run Locally

**Prerequisites:**  Node.js


Install dependencies:

1. npm install
2. npm audit fix
3. npm install @capacitor/core @capacitor/cli @capacitor/android
4. npx cap init
5. npm run build
6. npx cap sync
7. npx cap open android
