import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aluminium.calculator',
  appName: 'Thai',
  webDir: 'dist'
};

export default config;
