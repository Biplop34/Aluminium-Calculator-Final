var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
    } else {
      res.setHeader("Access-Control-Allow-Origin", "*");
    }
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
    res.setHeader("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Authorization");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });
  app.use(import_express.default.json({ limit: "50mb" }));
  app.use(import_express.default.urlencoded({ limit: "50mb", extended: true }));
  let ai = null;
  const getAiClient = () => {
    if (!ai) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY environment variable is not defined.");
      }
      ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
    }
    return ai;
  };
  app.post("/api/scan", async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        return res.status(400).json({ error: "No image data provided" });
      }
      const match = image.match(/^data:(image\/\w+);base64,(.+)$/);
      if (!match) {
        return res.status(400).json({ error: "Invalid image format. Expected a base64 Data URL." });
      }
      const mimeType = match[1];
      const base64Data = match[2];
      const client = getAiClient();
      const prompt = `You are a high-precision handwritten note reader and calculator dimensions extractor.
Look at the handwritten image, parse each listed item, and extract:
1. "height" - The value to the left of the 'x' or 'X' or '\xD7' multiplier symbol.
2. "length1" - The first value to the right of the 'x' symbol (or numerator of a fraction).
3. "length2" - The second value (e.g., if there's a fraction or a dash like "164-7 over 165-6", the denominator is length2. Or if written like "119/7 - 120/1" or "46 - 45/5", the second part after the dash is length2).

IMPORTANT REGIONAL NUMBERING RULES FOR THAI FABRICATION CALCULATION:
- A slash "/" or a dash "-" within any measurement represents a DECIMAL POINT "."!
  For example, "21/2" or "21-2" must be translated as "21.2".
  "137/5" must be translated as "137.5".
  "45/5" must be translated as "45.5".
  "119/7" must be translated as "119.7".
- If a number has no slash or dash, keep it as is (e.g., "150" is "150", "46" is "46").
- The serial numbers or list numbers (like \u2460, \u2461, \u2462, or 1, 2, 3) must correspond to the sequence.
- Extract all valid measurement rows. Keep them in the exact order found.

CRITICAL COMPLETENESS REQUIREMENT:
You MUST transcribe and extract EVERY SINGLE handwritten item on the page from top to bottom.
Do NOT skip any items, do NOT stop transcribing, do NOT truncate, and do NOT limit yourself to 15 or 17 items.
Even if there are 20, 30, 40, or more items, you must transcribe and output ALL of them in the JSON list!`;
      const modelCandidates = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-3.5-flash"];
      let lastError = null;
      let responseText = "";
      for (const modelName of modelCandidates) {
        try {
          console.log(`Attempting image scan with model: ${modelName}`);
          const response = await client.models.generateContent({
            model: modelName,
            contents: [
              {
                role: "user",
                parts: [
                  { text: prompt },
                  { inlineData: { mimeType, data: base64Data } }
                ]
              }
            ],
            config: {
              responseMimeType: "application/json",
              maxOutputTokens: 8192,
              responseSchema: {
                type: import_genai.Type.OBJECT,
                properties: {
                  items: {
                    type: import_genai.Type.ARRAY,
                    items: {
                      type: import_genai.Type.OBJECT,
                      properties: {
                        id: { type: import_genai.Type.NUMBER, description: "Item serial number index" },
                        height: { type: import_genai.Type.STRING, description: "Parsed height, e.g. '21.2'" },
                        length1: { type: import_genai.Type.STRING, description: "Parsed length 1, e.g. '46.0'" },
                        length2: { type: import_genai.Type.STRING, description: "Parsed length 2 (optional), e.g. '45.5' or empty/null" }
                      },
                      required: ["id", "height", "length1"]
                    }
                  }
                },
                required: ["items"]
              }
            }
          });
          if (response && response.text) {
            responseText = response.text;
            console.log(`Successfully completed scan using model: ${modelName}`);
            break;
          }
        } catch (err) {
          console.warn(`Model ${modelName} failed or busy:`, err.message || err);
          lastError = err;
        }
      }
      if (!responseText) {
        throw new Error(lastError ? lastError.message || JSON.stringify(lastError) : "All candidate models failed to respond.");
      }
      const result = JSON.parse(responseText);
      res.json(result);
    } catch (err) {
      console.error("Scanning Error:", err);
      res.status(500).json({ error: err.message || "Failed to parse handwriting image." });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    console.log("Vite middleware mounted for development");
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
    console.log("Serving static files from dist in production");
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
