export interface CalculationResults {
  outerSide: string;
  outerTop: string;
  outerBottom: string;
  lockVal: string;
  shutterTopBottom: string;
  glassHeightInch: string;
  glassLengthInch: string;
  isSmallFrame: boolean;
  isOneShutter: boolean;
  isPartition: boolean;
  isInchMode: boolean;
  netSectionHeight: string;
  netSectionLength: string;
}

export interface SavedCalculation {
  id: string;
  timestamp: number;
  sets: any[];
  results: any[];
  thaiSize?: '3' | '4';
}
