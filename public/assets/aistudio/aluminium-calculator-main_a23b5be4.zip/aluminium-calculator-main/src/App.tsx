import React, { useState } from 'react';
import ServiceSelector from './components/ServiceSelector';
import Layout from './components/Layout';
import App1 from './components/App1';
import App2 from './components/App2';
import { HUB_CONFIG } from './hub-config';

export default function App() {
  const [activeService, setActiveService] = useState<'app1' | 'app2' | null>(HUB_CONFIG.DEFAULT_APP);

  const handleSelect = (service: 'app1' | 'app2') => {
    setActiveService(service);
  };

  const handleExit = () => {
    setActiveService(null);
  };

  if (!activeService) {
    return <ServiceSelector onSelect={handleSelect} />;
  }

  return (
    <Layout 
      activeService={activeService} 
      onSwitch={handleSelect} 
      onExit={handleExit}
    >
      <div className={activeService === 'app1' ? 'block h-full' : 'hidden'}>
        <App1 />
      </div>
      <div className={activeService === 'app2' ? 'block h-full' : 'hidden'}>
        <App2 />
      </div>
    </Layout>
  );
}
