import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, RotateCcw, Clock } from 'lucide-react';
import { SavedCalculation } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: SavedCalculation[];
  onRestore: (calc: SavedCalculation) => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
}

export default function HistoryModal({ 
  isOpen, 
  onClose, 
  history, 
  onRestore, 
  onDelete, 
  onClearAll 
}: HistoryModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-[2rem] w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col shadow-2xl"
      >
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-100 rounded-xl">
              <Clock className="w-5 h-5 text-slate-600" />
            </div>
            <h2 className="text-xl font-bold text-slate-800">Calculation History</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {history.length === 0 ? (
            <div className="text-center py-12 text-slate-400 font-medium">
              No history found.
            </div>
          ) : (
            history.map((item) => (
              <div key={item.id} className="p-4 border border-slate-100 rounded-2xl hover:border-teal-200 transition-all group bg-slate-50/50">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="text-sm font-bold text-slate-800">
                      {new Date(item.timestamp).toLocaleString()}
                    </p>
                    <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                      {item.results.length} Items Calculated
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => onRestore(item)}
                      className="p-2 bg-white text-teal-600 border border-teal-100 rounded-xl hover:bg-teal-50 transition-all shadow-sm"
                      title="Restore"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => onDelete(item.id)}
                      className="p-2 bg-white text-red-500 border border-red-100 rounded-xl hover:bg-red-50 transition-all shadow-sm"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {history.length > 0 && (
          <div className="p-6 border-t border-slate-100">
            <button 
              onClick={onClearAll}
              className="w-full py-4 text-red-500 font-bold uppercase tracking-widest text-xs hover:bg-red-50 rounded-xl transition-all"
            >
              Clear All History
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
