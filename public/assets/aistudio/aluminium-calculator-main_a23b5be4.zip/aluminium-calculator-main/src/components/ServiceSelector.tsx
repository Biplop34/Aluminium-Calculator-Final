import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { HUB_CONFIG } from '@/src/hub-config';

interface ServiceSelectorProps {
  onSelect: (service: 'app1' | 'app2') => void;
}

export default function ServiceSelector({ onSelect }: ServiceSelectorProps) {
  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-center p-6 font-sans pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-5xl font-bold tracking-tight mb-4 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          AI Multi-Service Hub
        </h1>
        <p className="text-gray-400 text-lg max-w-md mx-auto">
          Choose a service to get started. You can switch between them anytime.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl">
        <ServiceCard 
          title={HUB_CONFIG.app1.name}
          description={HUB_CONFIG.app1.description}
          icon={<HUB_CONFIG.app1.icon className="w-8 h-8 text-blue-400" />}
          onClick={() => onSelect('app1')}
          delay={0.1}
        />
        <ServiceCard 
          title={HUB_CONFIG.app2.name}
          description={HUB_CONFIG.app2.description}
          icon={<HUB_CONFIG.app2.icon className="w-8 h-8 text-purple-400" />}
          onClick={() => onSelect('app2')}
          delay={0.2}
        />
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-16 text-xs text-gray-600 uppercase tracking-widest font-mono"
      >
        Powered by Google AI Studio
      </motion.div>
    </div>
  );
}

function ServiceCard({ title, description, icon, onClick, delay }: { 
  title: string; 
  description: string; 
  icon: React.ReactNode; 
  onClick: () => void;
  delay: number;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay }}
      onClick={onClick}
      className={cn(
        "group relative flex flex-col items-start p-8 rounded-2xl bg-[#141414] border border-white/10 text-left transition-all hover:border-white/20 hover:bg-[#1a1a1a]",
        "focus:outline-none focus:ring-2 focus:ring-blue-500/50"
      )}
    >
      <div className="mb-6 p-3 rounded-xl bg-white/5 group-hover:bg-white/10 transition-colors">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 group-hover:text-blue-400 transition-colors">{title}</h3>
      <p className="text-gray-400 text-sm leading-relaxed mb-6">
        {description}
      </p>
      <div className="mt-auto flex items-center text-sm font-medium text-blue-400 group-hover:translate-x-1 transition-transform">
        Launch Service <ArrowRight className="ml-2 w-4 h-4" />
      </div>
    </motion.button>
  );
}
