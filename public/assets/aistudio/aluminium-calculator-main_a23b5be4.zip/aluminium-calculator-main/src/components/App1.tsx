
import React, { useState, useEffect, useRef } from 'react';
import { CalculationResults, SavedCalculation } from '../types';
import HistoryModal from './HistoryModal';
import { toPng } from 'html-to-image';
import { Capacitor, CapacitorHttp } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';

const ALUM_COLORS = ['Silver Color', 'Bronze Color', 'Golden Color', 'SS Color'];
const ALUM_BRANDS = ['Chung Hua', 'KAI', 'PHP Shiny', 'PHP Solid', 'MAX', 'AXX', 'Others'];
const GLASS_TYPES = [
  'Clear Glass',
  'Navy Blue Mercury',
  'Lake Blue Mercury',
  'Ocean Blue',
  'Green Mercury',
  'Coffee Light',
  'Coffee Deep',
  'Golden Mercury',
  'Silver Mercury',
  'Solid Blue',
  'Solid Green',
  'Solid Black'
];

interface MeasurementSet {
  id: number;
  height: string;
  length1: string;
  length2: string;
  isOverridden?: boolean;
  isShutterOverridden?: boolean;
  isInchMode?: boolean;
}

interface CalculatedResultItem extends CalculationResults {
  id: number;
  label: string;
}

const Calculator: React.FC = () => {
  const [sets, setSets] = useState<MeasurementSet[]>([
    { id: Date.now(), height: '', length1: '', length2: '', isOverridden: false, isShutterOverridden: false, isInchMode: false }
  ]);
  const [resultsList, setResultsList] = useState<CalculatedResultItem[]>([]);
  const [history, setHistory] = useState<SavedCalculation[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [thaiSize, setThaiSize] = useState<'3' | '4'>('3');

  // Customer Details States
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerLocation, setCustomerLocation] = useState('');
  const [alumColor, setAlumColor] = useState('');
  const [alumBrand, setAlumBrand] = useState('');
  const [otherAlumBrand, setOtherAlumBrand] = useState('');
  const [glassType, setGlassType] = useState('');
  const [glassThickness, setGlassThickness] = useState('');
  const [isCustomerDetailsOpen, setIsCustomerDetailsOpen] = useState(false);
  const [activeSelectType, setActiveSelectType] = useState<'alumColor' | 'alumBrand' | 'glassType' | 'glassThickness' | null>(null);

  // Smart Import States
  const [isSmartImportOpen, setIsSmartImportOpen] = useState(false);
  const [importTab, setImportTab] = useState<'notepad' | 'photo'>('notepad');
  const [notepadText, setNotepadText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState<{ id: number; height: string; length1: string; length2: string }[]>([]);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [scanError, setScanError] = useState<string | null>(null);

  const [customApiUrl, setCustomApiUrl] = useState<string>(() => {
    // If we are actively on a Cloud Run URL, always prefer the current origin to keep things synchronized automatically.
    if (typeof window !== 'undefined' && window.location.origin && window.location.origin.includes('.run.app')) {
      return window.location.origin;
    }
    const saved = localStorage.getItem('custom_api_url');
    if (saved) return saved;
    return 'https://ais-pre-mdpyxbiiy7zdnvqi3omkot-77646848800.asia-east1.run.app';
  });
  const [customGeminiApiKey, setCustomGeminiApiKey] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('custom_gemini_api_key');
      return saved || '';
    }
    return '';
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('custom_api_url', customApiUrl);
  }, [customApiUrl]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('custom_gemini_api_key', customGeminiApiKey);
    }
  }, [customGeminiApiKey]);

  useEffect(() => {
    if (glassType === 'Clear Glass' && glassThickness === '5.5 MM') {
      setGlassThickness('5 MM');
    }
  }, [glassType, glassThickness]);
  
  const resultsRef = useRef<HTMLDivElement>(null);
  const exportTemplateRef = useRef<HTMLDivElement>(null);

  const FIVE_FEET_CM = 152.4;
  const SIX_FEET_CM = 182.88; 
  const FOUR_FEET_CM = 121.92; 
  const FORTY_TWO_IN_CM = 106.68;

  const FIVE_FEET_IN = 60;
  const SIX_FEET_IN = 72; 
  const FOUR_FEET_IN = 48; 
  const FORTY_TWO_IN = 42;
  
  const CM_TO_INCH = 0.393701;

  useEffect(() => {
    const saved = localStorage.getItem('thai_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading history", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('thai_history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.closest('button') ||
        target.closest('a') ||
        target.closest('[role="button"]') ||
        target.closest('input[type="checkbox"]') ||
        target.closest('input[type="radio"]')
      ) {
        try {
          if (typeof navigator !== 'undefined' && navigator.vibrate) {
            navigator.vibrate(15); // Light 15ms haptic vibration on button tap
          }
        } catch (err) {
          // Ignore haptic errors gracefully
        }
      }
    };

    document.addEventListener('click', handleGlobalClick, { capture: true });
    return () => {
      document.removeEventListener('click', handleGlobalClick, { capture: true });
    };
  }, []);

  useEffect(() => {
    if (resultsList.length > 0) {
      performCalculation(false);
    }
  }, [sets.map(s => `${s.isInchMode}-${s.isOverridden}-${s.isShutterOverridden}`).join(',')]);

  const formatInchesToSuta = (val: number, alreadyInInches: boolean = false): string => {
    if (val <= 0) return "0.0";
    const totalInches = alreadyInInches ? val : val * CM_TO_INCH;
    let intPart = Math.floor(totalInches);
    let suta = Math.round((totalInches - intPart) * 8);
    if (suta === 8) {
      intPart += 1;
      suta = 0;
    }
    return `${intPart}.${suta}`;
  };

  // Smart Notepad Parsing Logic
  const handleNotepadParse = () => {
    if (!notepadText.trim()) return;
    
    const lines = notepadText.split('\n');
    const parsedSets: MeasurementSet[] = [];
    
    lines.forEach(line => {
      // Remove starting numbers/dots/bullets, e.g. "1. " or "2) " or "- " safely without stripping the actual first number if there's no list bullet prefix
      const cleanLine = line.replace(/^\s*(?:[-*•+#]\s+|\d+[\.\)]\s+|\[\d+\]\s+|#\d+\s+)/, '').trim();
      if (!cleanLine) return;
      
      // Split by multiplying symbol (x, X, ×, *)
      const parts = cleanLine.split(/\s*[xX\*×]\s*/);
      if (parts.length >= 2) {
        let heightRaw = parts[0].trim();
        let rightSide = parts[1].trim();
        
        // Convert any slash or dash in height to decimal dot
        const height = heightRaw.replace('/', '.').replace('-', '.');
        
        let length1 = '';
        let length2 = '';
        
        // Check for space-separated dash separator, e.g. "46 - 45/5" or "119/7 - 120/1"
        const dashIndex = rightSide.indexOf(' - ');
        let lengths: string[] = [];
        if (dashIndex !== -1) {
          lengths = [
            rightSide.substring(0, dashIndex).trim(),
            rightSide.substring(dashIndex + 3).trim()
          ];
        } else {
          // Fallback if there are multiple spaces around a dash
          lengths = rightSide.split(/\s+-\s+/);
        }
        
        if (lengths.length >= 2) {
          length1 = lengths[0].replace('/', '.').replace('-', '.');
          length2 = lengths[1].replace('/', '.').replace('-', '.');
        } else {
          length1 = rightSide.replace('/', '.').replace('-', '.');
        }
        
        if (height && length1) {
          parsedSets.push({
            id: Date.now() + Math.random(),
            height,
            length1,
            length2,
            isOverridden: false,
            isShutterOverridden: false,
            isInchMode: false
          });
        }
      }
    });
    
    if (parsedSets.length > 0) {
      if (importMode === 'replace') {
        setSets(parsedSets);
      } else {
        // If appending, check if current sets are just a single empty row
        if (sets.length === 1 && !sets[0].height && !sets[0].length1) {
          setSets(parsedSets);
        } else {
          setSets([...sets, ...parsedSets]);
        }
      }
      setNotepadText('');
      setIsSmartImportOpen(false);
      alert(`Successfully imported ${parsedSets.length} items from notepad!`);
    } else {
      alert("No valid measurements found. Make sure format is like: Height x Length1 - Length2 (e.g., 21/2 x 46 - 45/5)");
    }
  };

  const resizeAndCompressImage = (dataUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const maxDim = 1200; // Optimal dimension for high-quality Gemini OCR and lightweight files
        let width = img.width;
        let height = img.height;
        
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          resolve(compressedDataUrl);
        } else {
          resolve(dataUrl);
        }
      };
      img.onerror = () => {
        resolve(dataUrl);
      };
      img.src = dataUrl;
    });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawDataUrl = reader.result as string;
        try {
          const compressed = await resizeAndCompressImage(rawDataUrl);
          setSelectedImage(compressed);
        } catch (err) {
          setSelectedImage(rawDataUrl);
        }
        setScanError(null);
        setScanResults([]);
      };
      reader.readAsDataURL(file);
    }
  };

  const updateScanResult = (index: number, field: 'height' | 'length1' | 'length2', value: string) => {
    setScanResults(prev => prev.map((item, idx) => idx === index ? { ...item, [field]: value } : item));
  };

  const removeScanResult = (index: number) => {
    setScanResults(prev => prev.filter((_, idx) => idx !== index));
  };

  const insertScanResultAt = (index: number) => {
    setScanResults(prev => {
      const copy = [...prev];
      copy.splice(index, 0, { id: 0, height: '', length1: '', length2: '' });
      return copy;
    });
  };

  const addScanResultAtEnd = () => {
    setScanResults(prev => [...prev, { id: 0, height: '', length1: '', length2: '' }]);
  };

  const normalizeScanningResult = (data: any): { items: any[] } => {
    if (!data) return { items: [] };

    // Helper for robust plain-text measurements parser
    const parsePlainTextMeasurements = (text: string): { items: any[] } => {
      const lines = text.split(/\r?\n/);
      const items: any[] = [];
      let itemIndex = 1;

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;

        // Check if line contains an 'x' or 'X' or '×' or '*' symbol
        if (!/[xX×*]/.test(trimmed)) continue;

        // Try to extract serial number/id if present
        let id = itemIndex;
        const leadMatch = trimmed.match(/^([①-⑳\d]+|\(\d+\)|\[\d+\]|[a-zA-Z]\d+)\s*[:.\-)]?\s*/);
        let lineRest = trimmed;
        if (leadMatch) {
          const rawId = leadMatch[1];
          lineRest = trimmed.slice(leadMatch[0].length).trim();
          
          const circledMap: { [key: string]: number } = {
            '①': 1, '②': 2, 'pattern3': 3, '③': 3, '④': 4, '⑤': 5, '⑥': 6, '⑦': 7, '⑧': 8, '⑨': 9, '⑩': 10,
            '⑪': 11, '⑫': 12, '⑬': 13, '⑭': 14, '⑮': 15, '⑯': 16, '⑰': 17, '⑱': 18, '⑲': 19, '⑳': 20
          };
          
          if (circledMap[rawId] !== undefined) {
            id = circledMap[rawId];
          } else {
            const parsedId = parseInt(rawId.replace(/[^\d]/g, ''), 10);
            if (!isNaN(parsedId)) {
              id = parsedId;
            }
          }
        }

        // Split into height and lengths parts
        const parts = lineRest.split(/[xX×*]/);
        if (parts.length < 2) continue;

        const rawHeight = parts[0].trim();
        const rawLengths = parts.slice(1).join('x').trim();

        // Scan result cleaning helper:
        // - Dashes '-' represent decimal points
        // - Only keep digits and dots
        const cleanScanNum = (val: string): string => {
          if (!val) return "";
          let cleaned = val.trim();
          cleaned = cleaned.replace(/-/g, '.');
          cleaned = cleaned.replace(/\s*\.\s*/g, '.');
          cleaned = cleaned.replace(/\.+/g, '.');
          cleaned = cleaned.replace(/[^\d.]/g, '');
          return cleaned;
        };

        const height = cleanScanNum(rawHeight);

        let rawL1 = rawLengths;
        let rawL2 = '';

        const lengthParts = rawLengths.split('/');
        if (lengthParts.length > 1) {
          rawL1 = lengthParts[0].trim();
          rawL2 = lengthParts[1].trim();
        } else {
          const wordMatch = rawLengths.match(/\s+(over|under|by|divided\s+by)\s+/i);
          if (wordMatch) {
            const idx = rawLengths.indexOf(wordMatch[0]);
            rawL1 = rawLengths.substring(0, idx).trim();
            rawL2 = rawLengths.substring(idx + wordMatch[0].length).trim();
          }
        }

        const length1 = cleanScanNum(rawL1);
        const length2 = cleanScanNum(rawL2);

        if (height || length1) {
          items.push({
            id,
            height,
            length1,
            length2: length2 || ''
          });
          itemIndex++;
        }
      }

      return { items };
    };

    let parsedJson: any = null;
    if (typeof data === "string") {
      const cleanText = data.trim();
      if (cleanText.startsWith("{") || cleanText.startsWith("[")) {
        try {
          parsedJson = JSON.parse(cleanText);
        } catch (e) {
          console.warn("Failed to parse string as JSON", e);
        }
      }

      if (!parsedJson) {
        let textToParse = cleanText;
        if (textToParse.startsWith("```")) {
          textToParse = textToParse.replace(/^```(?:json|text|plain)?/i, "").replace(/```$/, "").trim();
        }
        if (textToParse.startsWith("{") || textToParse.startsWith("[")) {
          try {
            parsedJson = JSON.parse(textToParse);
          } catch (e) {
            // Ignore
          }
        }
        
        if (!parsedJson) {
          return parsePlainTextMeasurements(textToParse);
        }
      }
    } else {
      parsedJson = data;
    }

    if (parsedJson) {
      let rawItems: any[] = [];
      if (Array.isArray(parsedJson)) {
        rawItems = parsedJson;
      } else if (typeof parsedJson === "object") {
        if (parsedJson.items && Array.isArray(parsedJson.items)) {
          rawItems = parsedJson.items;
        } else {
          const arrayKey = Object.keys(parsedJson).find((key) => Array.isArray(parsedJson[key]));
          if (arrayKey) {
            rawItems = parsedJson[arrayKey];
          } else if (parsedJson.height || parsedJson.length1) {
            rawItems = [parsedJson];
          }
        }
      }

      if (rawItems.length > 0) {
        const items = rawItems
          .map((item, index) => {
            if (!item || typeof item !== "object") return null;

            let id = index + 1;
            if (typeof item.id === "number") {
              id = item.id;
            } else if (item.id !== undefined && item.id !== null) {
              const parsedId = parseInt(String(item.id), 10);
              if (!isNaN(parsedId)) id = parsedId;
            }

            let height = "";
            const heightKeys = ["height", "h", "hight", "Height"];
            for (const k of heightKeys) {
              if (item[k] !== undefined && item[k] !== null) {
                height = String(item[k]).trim();
                break;
              }
            }

            let length1 = "";
            let length2 = "";

            const l1Keys = ["length1", "length_1", "l1", "length", "len1", "Length1"];
            for (const k of l1Keys) {
              if (item[k] !== undefined && item[k] !== null) {
                length1 = String(item[k]).trim();
                break;
              }
            }

            const l2Keys = ["length2", "length_2", "l2", "len2", "Length2"];
            for (const k of l2Keys) {
              if (item[k] !== undefined && item[k] !== null) {
                length2 = String(item[k]).trim();
                break;
              }
            }

            if (!length1) {
              const remainingKeys = Object.keys(item).filter(
                (k) => !["id", "height", "h", "hight", "Height"].includes(k)
              );
              if (remainingKeys.length > 0) {
                length1 = String(item[remainingKeys[0]]).trim();
                if (remainingKeys.length > 1) {
                  length2 = String(item[remainingKeys[1]]).trim();
                }
              }
            }

            // If length1 contains a slash '/' (fraction), split it!
            if (length1.includes('/')) {
              const lparts = length1.split('/');
              length1 = lparts[0].trim();
              length2 = lparts[1].trim();
            }

            // Scan result cleaning helper:
            // - Dashes '-' represent decimal points
            // - Only keep digits and dots
            const cleanScanNum = (val: string): string => {
              if (!val) return "";
              let cleaned = val.trim();
              cleaned = cleaned.replace(/-/g, '.');
              cleaned = cleaned.replace(/\s*\.\s*/g, '.');
              cleaned = cleaned.replace(/\.+/g, '.');
              cleaned = cleaned.replace(/[^\d.]/g, '');
              return cleaned;
            };

            return {
              id,
              height: cleanScanNum(height),
              length1: cleanScanNum(length1),
              length2: cleanScanNum(length2),
            };
          })
          .filter(Boolean);

        if (items.length > 0) {
          return { items };
        }
      }
    }

    if (typeof data === "string") {
      return parsePlainTextMeasurements(data);
    }

    return { items: [] };
  };

  const safePostRequest = async (url: string, payload: any) => {
    // If we are on native platform, try using CapacitorHttp first (which completely bypasses CORS)
    if (Capacitor.isNativePlatform()) {
      try {
        console.log(`[CapacitorHttp] Attempting POST to: ${url}`);
        const options = {
          url: url,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          data: payload,
          connectTimeout: 20000,
          readTimeout: 40000,
        };
        const response = await CapacitorHttp.post(options);
        
        console.log(`[CapacitorHttp] Response status: ${response.status}`);
        
        if (response.status >= 200 && response.status < 300) {
          let parsedData = response.data;
          if (typeof parsedData === 'string') {
            try {
              parsedData = JSON.parse(parsedData);
            } catch (e) {
              // ignore
            }
          }
          return parsedData;
        } else {
          let errorMsg = `HTTP status ${response.status}`;
          if (response.data) {
            if (typeof response.data === 'object' && response.data.error) {
              errorMsg = response.data.error;
            } else if (typeof response.data === 'string') {
              try {
                const parsed = JSON.parse(response.data);
                errorMsg = parsed.error || errorMsg;
              } catch (e) {
                errorMsg = response.data;
              }
            }
          }
          throw new Error(errorMsg);
        }
      } catch (capErr: any) {
        console.warn(`[CapacitorHttp] Failed for ${url}:`, capErr.message || capErr);
        // Fall through to standard fetch
      }
    }

    // Fallback: Standard browser fetch
    console.log(`[Fetch] Attempting POST to: ${url}`);
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('text/html')) {
      throw new Error(`Endpoint returned HTML instead of JSON. The server might be offline or starting up.`);
    }

    if (!res.ok) {
      let errMsg = 'Failed to scan image';
      try {
        const errData = await res.json();
        errMsg = errData.error || errMsg;
      } catch (e) {
        errMsg = `HTTP status ${res.status}`;
      }
      throw new Error(errMsg);
    }

    return await res.json();
  };

  const callDirectGeminiAPI = async (base64ImageWithHeader: string, apiKey: string) => {
    const match = base64ImageWithHeader.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!match) {
      throw new Error("Invalid image format selected.");
    }
    const mimeType = match[1];
    const base64Data = match[2];

    const prompt = `You are a professional, high-precision handwritten note reader for Thai window fabrication.
Look at the handwritten image and extract all the measurement rows in order.

CRITICAL MEASUREMENT RULES:
1. Each line is structured as: [ID/Serial] [Height] x [Length 1] / [Length 2]
   - The symbol 'x', 'X', '×', or '*' separates the Height and Length.
   - The slash '/' separates Length 1 and Length 2 (Length 2 is optional and only present if there is a '/').
   - Dashes '-' inside any number represent a DECIMAL POINT '.'. For example:
     * '177-1' must be extracted as '177.1'
     * '165-2' must be extracted as '165.2'
     * '197-5' must be extracted as '197.5'
     * '197-6' must be extracted as '197.6'
     * '43-3' must be extracted as '43.3'
   - Slashes '/' are ONLY used to separate Length 1 and Length 2. Do NOT treat slashes as decimal points when they divide two numbers! For example:
     * '165-2 / 167' means Length 1 is '165.2' and Length 2 is '167'
     * '212 / 211-5' means Length 1 is '212' and Length 2 is '211.5'
     * '43 / 43-3' means Length 1 is '43' and Length 2 is '43.3'
   - If a number has no dash or slash, keep it as an integer/decimal (e.g., '212' is '212', '198' is '198').

EXAMPLES:
- "① 177-1 x 165-2 / 167" -> height: "177.1", length1: "165.2", length2: "167"
- "② 197-5 x 212" -> height: "197.5", length1: "212", length2: ""
- "③ 197-6 x 212 / 211-5" -> height: "197.6", length1: "212", length2: "211.5"
- "⑦ 36 x 43 / 43-3" -> height: "36", length1: "43", length2: "43.3"

CRITICAL COMPLETENESS REQUIREMENT:
You MUST transcribe and extract EVERY SINGLE handwritten item on the page from top to bottom.
Do NOT skip any items, do NOT stop transcribing, do NOT truncate, and do NOT limit yourself.
Output the extracted items in the exact order found.`;

    const models = ["gemini-3.6-flash", "gemini-2.5-flash"];
    let lastError: any = null;
    let responseText = "";

    // Method 1: JSON Schema mode
    for (const model of models) {
      try {
        console.log(`Trying direct client-side JSON scan with model: ${model}`);
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
        
        let responseJson: any;
        const payload = {
          contents: [
            {
              parts: [
                { text: prompt },
                { inlineData: { mimeType: mimeType, data: base64Data } }
              ]
            }
          ],
          generationConfig: {
            responseMimeType: "application/json",
            responseSchema: {
              type: "OBJECT",
              properties: {
                items: {
                  type: "ARRAY",
                  items: {
                    type: "OBJECT",
                    properties: {
                      id: { type: "INTEGER", description: "Item serial number index" },
                      height: { type: "STRING", description: "Parsed height, e.g. '21.2'" },
                      length1: { type: "STRING", description: "Parsed length 1, e.g. '46.0'" },
                      length2: { type: "STRING", description: "Parsed length 2 (optional), e.g. '45.5' or empty/null" }
                    },
                    required: ["id", "height", "length1"]
                  }
                }
              },
              required: ["items"]
            }
          }
        };

        if (Capacitor.isNativePlatform()) {
          const res = await CapacitorHttp.post({
            url: url,
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            data: payload
          });

          if (res.status >= 200 && res.status < 300) {
            responseJson = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          } else {
            throw new Error(`Status ${res.status}: ${JSON.stringify(res.data)}`);
          }
        } else {
          const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });

          if (res.ok) {
            responseJson = await res.json();
          } else {
            const errText = await res.text();
            throw new Error(`Status ${res.status}: ${errText}`);
          }
        }

        const text = responseJson.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text && text.trim().length > 0) {
          const parsed = JSON.parse(text.trim());
          const normalized = normalizeScanningResult(parsed);
          if (normalized && normalized.items && normalized.items.length > 0) {
            responseText = text;
            break;
          }
        }
      } catch (e: any) {
        console.warn(`Direct client model ${model} JSON mode failed:`, e.message || e);
        lastError = e;
      }
    }

    // Fallback Method 2: Plain Text Transcription mode
    if (!responseText) {
      console.log("--- Direct client-side Falling back to Method 2 Plain Text Mode ---");
      const plainTextPrompt = `You are a professional, high-precision handwritten note reader.
Look at the handwritten image, find all lines of measurements, and transcribe them.
You MUST write each row in this exact format:
id: height x length1 / length2

Examples:
1: 177-1 x 165-2 / 167
2: 197-5 x 212
3: 197-6 x 212 / 211-5

Only output the plain list, one item per line. Do not include any other markdown text, headers, explanations or summaries.
IMPORTANT THAI MEASUREMENT FORMAT RULES:
Keep any slashes "/" and dashes "-" as they are written (e.g. 177-1, 165-2).
Transcribe EVERY SINGLE row of measurement from top to bottom. Ensure no lines are skipped!`;

      for (const model of models) {
        try {
          console.log(`Trying direct client-side plain text transcription with model: ${model}`);
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
          
          let responseJson: any;
          const payload = {
            contents: [
              {
                parts: [
                  { text: plainTextPrompt },
                  { inlineData: { mimeType: mimeType, data: base64Data } }
                ]
              }
            ]
          };

          if (Capacitor.isNativePlatform()) {
            const res = await CapacitorHttp.post({
              url: url,
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              data: payload
            });

            if (res.status >= 200 && res.status < 300) {
              responseJson = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            } else {
              throw new Error(`Status ${res.status}`);
            }
          } else {
            const res = await fetch(url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload)
            });

            if (res.ok) {
              responseJson = await res.json();
            } else {
              throw new Error(`Status ${res.status}`);
            }
          }

          const text = responseJson.candidates?.[0]?.content?.parts?.[0]?.text;
          if (text && text.trim().length > 0) {
            responseText = text;
            break;
          }
        } catch (e: any) {
          console.warn(`Direct client model ${model} Plain Text mode failed:`, e.message || e);
          lastError = e;
        }
      }
    }

    if (!responseText) {
      throw lastError || new Error("All direct Gemini API candidate models and fallback methods failed.");
    }

    const normalized = normalizeScanningResult(responseText);
    if (normalized && normalized.items && normalized.items.length > 0) {
      return normalized;
    } else {
      throw new Error("Direct Gemini response did not contain any valid measurement items.");
    }
  };

  const handlePhotoScan = async () => {
    if (!selectedImage) return;
    
    setIsScanning(true);
    setScanError(null);
    setScanResults([]);
    
    try {
      // 1. If user provided their own API Key, always prioritize direct client-side scanning (extremely fast and bypasses Cloud Run auth gateways)
      if (customGeminiApiKey && customGeminiApiKey.trim()) {
        try {
          console.log("Prioritizing Direct Client-Side Gemini Scan with User's API Key...");
          const data = await callDirectGeminiAPI(selectedImage, customGeminiApiKey.trim());
          const normalized = normalizeScanningResult(data);
          if (normalized && normalized.items && normalized.items.length > 0) {
            setScanResults(normalized.items);
            console.log("Direct scan completed successfully!");
            setIsScanning(false);
            return;
          }
        } catch (directErr: any) {
          console.warn("Direct Client-Side Scan failed, falling back to Server URL pathways...", directErr);
          // Don't throw, let it fall through to server path
        }
      }

      const isLocalOrNative = Capacitor.isNativePlatform() || 
                              window.location.origin.includes('localhost') || 
                              window.location.origin.startsWith('capacitor://') ||
                              window.location.origin.startsWith('file://');

      const rawEndpoints = [];
      
      // Method A: Custom Backend URL (user setting)
      if (customApiUrl) {
        const cleanUrl = customApiUrl.trim().replace(/\/$/, '');
        rawEndpoints.push(cleanUrl.endsWith('/api/scan') ? cleanUrl : `${cleanUrl}/api/scan`);
      }

      // Method B: Standard Relative Path (always reliable for pure web view)
      if (!isLocalOrNative) {
        rawEndpoints.push('/api/scan');
      }

      // Method C: Emulator IP
      rawEndpoints.push('http://10.0.2.2:3000/api/scan');
      rawEndpoints.push('http://10.0.3.2:3000/api/scan');

      // Method D: Localhost
      rawEndpoints.push('http://localhost:3000/api/scan');
      rawEndpoints.push('http://127.0.0.1:3000/api/scan');

      // Method E: Current window origin
      if (typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost')) {
        const currentOrigin = window.location.origin.replace(/\/$/, '');
        rawEndpoints.push(`${currentOrigin}/api/scan`);
      }

      // Method F: High-probability Cloud Run URLs
      rawEndpoints.push('https://ais-dev-mdpyxbiiy7zdnvqi3omkot-77646848800.asia-east1.run.app/api/scan');
      rawEndpoints.push('https://ais-pre-mdpyxbiiy7zdnvqi3omkot-77646848800.asia-east1.run.app/api/scan');

      // Deduplicate keeping priority
      const endpoints = Array.from(new Set(rawEndpoints));

      let scanData: any = null;
      const errors: string[] = [];

      for (const url of endpoints) {
        try {
          const data = await safePostRequest(url, { image: selectedImage });
          const normalized = normalizeScanningResult(data);
          if (normalized && normalized.items && normalized.items.length > 0) {
            scanData = normalized;
            console.log(`Scan completed successfully from server path: ${url}`);
            break;
          } else {
            throw new Error('Invalid response structure from scanner.');
          }
        } catch (err: any) {
          const errMsg = err.message || String(err);
          console.warn(`Scan attempt failed for ${url}:`, errMsg);
          errors.push(`${url}: ${errMsg}`);
        }
      }

      if (scanData && scanData.items) {
        setScanResults(scanData.items);
      } else {
        const descriptive = errors.find(e => 
          !e.includes('Failed to fetch') && 
          !e.includes('TypeError') && 
          !e.includes('NetworkError')
        );
        if (descriptive) {
          throw new Error(descriptive);
        } else if (errors.length > 0) {
          throw new Error(errors.join('\n'));
        } else {
          throw new Error('Failed to fetch. All scanning servers are currently offline or busy.');
        }
      }
    } catch (err: any) {
      console.error(err);
      setScanError(err.message || 'An error occurred during scanning.');
    } finally {
      setIsScanning(false);
    }
  };

  const handleImportScanResults = () => {
    if (scanResults.length === 0) return;
    
    const parsedSets: MeasurementSet[] = scanResults.map(item => ({
      id: Date.now() + Math.random(),
      height: item.height || '',
      length1: item.length1 || '',
      length2: item.length2 || '',
      isOverridden: false,
      isShutterOverridden: false,
      isInchMode: false
    }));
    
    if (importMode === 'replace') {
      setSets(parsedSets);
    } else {
      if (sets.length === 1 && !sets[0].height && !sets[0].length1) {
        setSets(parsedSets);
      } else {
        setSets([...sets, ...parsedSets]);
      }
    }
    
    setSelectedImage(null);
    setScanResults([]);
    setIsSmartImportOpen(false);
    alert(`Successfully imported ${parsedSets.length} items from scanned image!`);
  };

  const addSet = () => {
    setSets([...sets, { id: Date.now(), height: '', length1: '', length2: '', isOverridden: false, isShutterOverridden: false, isInchMode: false }]);
  };

  const removeSet = (id: number) => {
    if (sets.length > 1) {
      setSets(sets.filter(s => s.id !== id));
    }
  };

  const updateSet = (id: number, field: keyof MeasurementSet, value: any) => {
    setSets(sets.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const toggleUnitMode = (id: number, currentMode: boolean) => {
    const newMode = !currentMode;
    setSets(prev => prev.map(s => {
      if (s.id === id) {
        const convert = (val: string) => {
          const num = parseFloat(val);
          if (isNaN(num) || num <= 0) return val;
          return newMode ? (num * CM_TO_INCH).toFixed(2) : (num / CM_TO_INCH).toFixed(2);
        };
        return {
          ...s,
          isInchMode: newMode,
          height: convert(s.height),
          length1: convert(s.length1),
          length2: s.length2 ? convert(s.length2) : ''
        };
      }
      return s;
    }));
  };

  const performCalculation = (shouldScroll: boolean = true) => {
    const newResults: CalculatedResultItem[] = [];

    sets.forEach((set, index) => {
      const H = parseFloat(set.height) || 0;
      const L1 = parseFloat(set.length1) || 0;
      const L2 = parseFloat(set.length2) || 0;

      if (H > 0 && L1 > 0) {
        const isInchMode = !!set.isInchMode;
        const qualifiesPartition = isInchMode ? (H >= SIX_FEET_IN && L1 >= FOUR_FEET_IN) : (H >= SIX_FEET_CM && L1 >= FOUR_FEET_CM);
        const qualifiesFanLight = !isInchMode && H < 61 && L1 < 61;
        const qualifiesShutterCM = H >= FIVE_FEET_CM && L1 < FORTY_TWO_IN_CM;
        const qualifiesShutterIN = H >= FIVE_FEET_IN && L1 < FORTY_TWO_IN;
        const qualifiesOneShutterBase = !qualifiesPartition && (qualifiesShutterCM || qualifiesShutterIN);
        
        const isFanLight = qualifiesFanLight && !set.isOverridden;
        const isPartition = qualifiesPartition;
        const isOneShutter = qualifiesOneShutterBase && !set.isShutterOverridden;

        let finalOuterSide, finalOuterTop, finalOuterBottom, finalLockVal, finalShutterTopBottom, gH, gL;
        let netSectionHeight = '';
        let netSectionLength = '';

        if (isOneShutter) {
          if (isInchMode) {
            finalOuterSide = formatInchesToSuta(H, true);
            finalOuterTop = formatInchesToSuta(L1 * 2, true);
            finalOuterBottom = finalOuterTop;
            finalLockVal = formatInchesToSuta(H - (2.7 / 2.54), true);
            finalShutterTopBottom = formatInchesToSuta(L1 - 4, true);
            gH = formatInchesToSuta(H - (2.7 / 2.54) - (8 / 2.54), true);
            gL = formatInchesToSuta(L1 - 4 + (1.3 / 2.54), true);
          } else {
            finalOuterSide = H.toFixed(1);
            finalOuterTop = (L1 * 2).toFixed(1);
            finalOuterBottom = finalOuterTop;
            finalLockVal = (H - 2.7).toFixed(1);
            finalShutterTopBottom = (L1 - 10.16).toFixed(1);
            gH = formatInchesToSuta(H - 2.7 - 8);
            gL = formatInchesToSuta(L1 - 10.16 + 1.3);
          }
        } else {
          const maxLength = Math.max(L1, L2);
          finalOuterSide = H.toFixed(1);
          finalOuterTop = (L1 - 1.3).toFixed(1);
          finalOuterBottom = L2 > 0 ? (L2 - 1.3).toFixed(1) : finalOuterTop;
          finalLockVal = isFanLight ? (H - 2).toFixed(1) : (H - 2.7).toFixed(1);
          finalShutterTopBottom = ((maxLength - 15) / 2).toFixed(1);

          gH = formatInchesToSuta(parseFloat(finalLockVal) - 8);
          gL = formatInchesToSuta(parseFloat(finalShutterTopBottom) + 1.3);

          netSectionHeight = (H - 3).toFixed(1);
          netSectionLength = (parseFloat(finalShutterTopBottom) + 8.5).toFixed(1);
        }

        // Refactored Label: Removed "Item #X" prefix here as we add it via UI badges
        let finalLabel = isFanLight ? "Fan Light" : 
                         isPartition ? "Partition" : 
                         isOneShutter ? `1 Shutter ${isInchMode ? 'IN' : 'CM'}` : 
                         "Standard Window";

        newResults.push({
          id: set.id,
          label: finalLabel,
          outerSide: finalOuterSide,
          outerTop: finalOuterTop,
          outerBottom: finalOuterBottom,
          lockVal: finalLockVal,
          shutterTopBottom: finalShutterTopBottom,
          glassHeightInch: gH,
          glassLengthInch: gL,
          isSmallFrame: isFanLight,
          isOneShutter: isOneShutter,
          isPartition: isPartition,
          isInchMode: isInchMode,
          netSectionHeight,
          netSectionLength
        });
      }
    });

    if (newResults.length > 0) {
      setResultsList(newResults);
      if (shouldScroll) {
        const newHistoryItem: SavedCalculation = {
          id: Date.now().toString(),
          timestamp: Date.now(),
          sets: sets.map(s => ({...s})),
          results: newResults,
          thaiSize: thaiSize
        };
        setHistory(prev => [newHistoryItem, ...prev].slice(0, 50));
        setTimeout(() => {
          const section = document.getElementById('results-section');
          if (section) window.scrollTo({ top: section.offsetTop - 20, behavior: 'smooth' });
        }, 100);
      }
    }
  };

  const calculate = () => performCalculation(true);

  const restoreFromHistory = (calc: SavedCalculation) => {
    setSets(calc.sets);
    setResultsList(calc.results);
    if (calc.thaiSize) {
      setThaiSize(calc.thaiSize);
    }
    setIsHistoryOpen(false);
  };

  const clearAll = () => {
    setSets([{ id: Date.now(), height: '', length1: '', length2: '', isOverridden: false, isShutterOverridden: false, isInchMode: false }]);
    setResultsList([]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveAsImage = async () => {
    if (!exportTemplateRef.current || resultsList.length === 0) return;
    
    setIsSaving(true);
    try {
      await new Promise(r => setTimeout(r, 800));
      
      const dataUrl = await toPng(exportTemplateRef.current, {
        cacheBust: true,
        backgroundColor: '#ffffff',
        pixelRatio: 2.5, 
      });
      
      const now = new Date();
      const fileName = `Thai_Report_${now.getTime()}.png`;
      
      if (Capacitor.isNativePlatform()) {
        try {
          // Request permissions first
          const perm = await Filesystem.checkPermissions();
          if (perm.publicStorage !== 'granted') {
            await Filesystem.requestPermissions();
          }

          const base64Data = dataUrl.split(',')[1];
          await Filesystem.writeFile({
            path: `Download/${fileName}`,
            data: base64Data,
            directory: Directory.ExternalStorage,
          });

          alert("Report saved to Downloads folder!");
        } catch (err: any) {
          // Fallback to Documents if Download folder path is restricted
          const base64Data = dataUrl.split(',')[1];
          await Filesystem.writeFile({
            path: fileName,
            data: base64Data,
            directory: Directory.Documents,
          });

          alert("Report saved to Documents folder!");
        }
      } else {
        // Web Save Logic
        const link = document.createElement('a');
        link.href = dataUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    } catch (err: any) {
      console.error('Failed to save report', err);
      alert(`Error saving report: ${err.message || 'Unknown error'}. Please try again.`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-full bg-slate-50 p-3 md:p-8 space-y-4 md:space-y-8 pb-12">
      {/* HIDDEN EXPORT TEMPLATE */}
      <div className="fixed -left-[10000px] top-0 pointer-events-none">
        <div ref={exportTemplateRef} className="w-[1200px] bg-white p-12 relative flex flex-col justify-between" style={{ minHeight: '1697px', height: 'auto' }}>
          <div className="relative z-10 flex-1 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start border-b-4 border-slate-900 pb-6 mb-8">
                <div>
                  <h1 className="text-5xl font-black text-slate-900 uppercase tracking-tighter mb-2">THAI</h1>
                  {(customerName || customerPhone || customerLocation || alumBrand || alumColor || glassType || glassThickness) && (
                    <div className="text-slate-900 font-bold text-base space-y-1 mt-2 text-left">
                      {customerName && <p>Customer name : {customerName}</p>}
                      {customerPhone && <p>Customer Phone Number : {customerPhone}</p>}
                      {customerLocation && <p>Customer / Site Location : {customerLocation}</p>}
                      {(alumBrand || alumColor || glassType || glassThickness) && (
                        <p>
                          {[
                            alumBrand ? (alumBrand === 'Others' ? (otherAlumBrand || 'Custom Brand') : alumBrand) : '',
                            alumColor ? alumColor.replace(' Color', '') : '',
                            (alumBrand || alumColor) ? 'Aluminum' : '',
                            (glassThickness || glassType) ? ',' : '',
                            glassThickness,
                            glassType,
                            (glassType || glassThickness) ? 'Glass' : ''
                          ].filter(Boolean).join(' ').replace(' ,', ',')}
                        </p>
                      )}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-xl font-black text-slate-900">{new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                  <p className="text-sm font-bold text-teal-600 uppercase tracking-widest">{new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-black text-center text-sm">
                  <thead>
                    <tr className="bg-white">
                      <th rowSpan={2} className="border border-black p-2 font-bold text-black">Gap NO.</th>
                      <th colSpan={thaiSize === '3' ? 4 : 6} className="border border-black p-2 font-bold text-black">Aluminium Section</th>
                      <th colSpan={2} className="border border-black p-2 font-bold text-black">Glass Section</th>
                    </tr>
                    <tr className="bg-white">
                      <th className="border border-black p-2 font-bold text-black">Outer Side</th>
                      <th className="border border-black p-2 font-bold text-black">Outer T/B</th>
                      <th className="border border-black p-2 font-bold text-black">S/I Lock</th>
                      <th className="border border-black p-2 font-bold text-black">Shutter T/B</th>
                      {thaiSize !== '3' && (
                        <>
                          <th className="border border-black p-2 font-bold text-black">N/S Height</th>
                          <th className="border border-black p-2 font-bold text-black">N/S Length</th>
                        </>
                      )}
                      <th className="border border-black p-2 font-bold text-black">Glass Height</th>
                      <th className="border border-black p-2 font-bold text-black">Glass Length</th>
                    </tr>
                  </thead>
                  <tbody>
                    {resultsList.map((res, i) => (
                      <tr key={res.id} className="bg-white">
                        <td className="border border-black p-2 font-medium text-black">{i + 1}</td>
                        <td className="border border-black p-2 text-black">{res.outerSide}</td>
                        <td className="border border-black p-2 text-black">
                          {res.outerTop === res.outerBottom ? (
                            res.outerTop
                          ) : (
                            <div className="flex flex-col text-[10px] leading-tight">
                              <span>T: {res.outerTop}</span>
                              <span>B: {res.outerBottom}</span>
                            </div>
                          )}
                        </td>
                        <td className="border border-black p-2 text-black">{res.lockVal}</td>
                        <td className="border border-black p-2 text-black">{res.shutterTopBottom}</td>
                        {thaiSize !== '3' && (
                          <>
                            <td className="border border-black p-2 text-black">{res.netSectionHeight || ''}</td>
                            <td className="border border-black p-2 text-black">{res.netSectionLength || ''}</td>
                          </>
                        )}
                        <td className="border border-black p-2 text-black">{res.glassHeightInch}"</td>
                        <td className="border border-black p-2 text-black">{res.glassLengthInch}"</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-12 pt-6 border-t-2 border-slate-100 text-center">
               <p className="text-sm font-black text-slate-300 uppercase tracking-[0.6em]">Professional Thai Fabrication Tool</p>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full">
        <div className="bg-white md:rounded-[2.5rem] shadow-2xl shadow-slate-200/50 border-y border-slate-200 md:border overflow-hidden">
          <div className="bg-slate-50 border-b border-slate-100 p-4 md:p-8 flex justify-between items-center gap-3">
            <div className="flex items-center gap-3 md:gap-4 overflow-hidden">
              <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-teal-100 text-teal-600 shadow-inner">
                <svg className="w-5 h-5 md:w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              </div>
              <div className="overflow-hidden">
                <h2 className="text-lg md:text-xl font-black text-slate-800 tracking-tight leading-none truncate md:leading-normal">Thai Specs</h2>
                <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5 md:mt-0 truncate">Configure frame</p>
              </div>
            </div>
            <button onClick={() => setIsHistoryOpen(true)} className="flex-shrink-0 px-2.5 md:px-4 py-2 md:py-3 bg-white hover:bg-slate-100 text-slate-600 rounded-xl md:rounded-2xl transition-all border border-slate-200 flex items-center gap-2 group shadow-sm active:scale-95">
              <svg className="flex-shrink-0 w-4 h-4 md:w-5 md:h-5 transition-transform group-hover:rotate-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-[10px] md:text-xs font-black uppercase tracking-wider md:tracking-widest whitespace-nowrap">History</span>
            </button>
          </div>

          <div className="p-4 md:p-8 space-y-6 md:space-y-8">
            {/* 3 Inch / 4 Inch Toggle Option */}
            <div className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl border border-slate-100 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-1.5 h-6 bg-teal-500 rounded-full"></div>
                <div>
                  <h4 className="text-xs md:text-sm font-black text-slate-800 tracking-tight uppercase leading-none">Frame Size</h4>
                  <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Select 3 Inch or 4 Inch profile</p>
                </div>
              </div>
              <div className="flex bg-slate-200/50 p-0.5 rounded-xl border border-slate-200">
                <button
                  onClick={() => setThaiSize('3')}
                  className={`px-3 md:px-5 py-2 rounded-lg text-[9px] md:text-xs font-black uppercase tracking-wider transition-all duration-200 active:scale-95 ${
                    thaiSize === '3'
                      ? 'bg-teal-600 text-white shadow-md'
                      : 'text-slate-600 hover:text-teal-600'
                  }`}
                >
                  3 Inch
                </button>
                <button
                  onClick={() => setThaiSize('4')}
                  className={`px-3 md:px-5 py-2 rounded-lg text-[9px] md:text-xs font-black uppercase tracking-wider transition-all duration-200 active:scale-95 ${
                    thaiSize === '4'
                      ? 'bg-teal-600 text-white shadow-md'
                      : 'text-slate-600 hover:text-teal-600'
                  }`}
                >
                  4 Inch
                </button>
              </div>
            </div>

            {/* Smart Scanner & Notepad Parser Panel */}
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden transition-all duration-300">
              <style dangerouslySetInnerHTML={{__html: `
                @keyframes scanBeam {
                  0% { top: 0%; opacity: 0.8; }
                  50% { top: 100%; opacity: 0.8; }
                  100% { top: 0%; opacity: 0.8; }
                }
                .scanner-laser-line {
                  animation: scanBeam 2.5s ease-in-out infinite;
                }
              `}} />

              <button
                type="button"
                onClick={() => setIsSmartImportOpen(!isSmartImportOpen)}
                className="w-full flex items-center justify-between px-4 md:px-6 py-4 bg-slate-100/80 hover:bg-slate-100/90 transition-all font-black text-[10px] md:text-xs text-slate-700 uppercase tracking-widest"
              >
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-teal-100 flex items-center justify-center text-teal-600">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <span>📸 SMART SCANNER & NOTEPAD IMPORT</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg
                    className={`w-4 h-4 text-slate-500 transition-transform duration-300 ${isSmartImportOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>

              {isSmartImportOpen && (
                <div className="p-4 md:p-6 space-y-6 border-t border-slate-100 bg-white">
                  {/* Selector Tabs */}
                  <div className="flex bg-slate-100 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setImportTab('notepad')}
                      className={`flex-1 py-2.5 rounded-lg text-[10px] md:text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                        importTab === 'notepad'
                          ? 'bg-white text-teal-600 shadow-sm'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      📄 Notepad Text
                    </button>
                    <button
                      type="button"
                      onClick={() => setImportTab('photo')}
                      className={`flex-1 py-2.5 rounded-lg text-[10px] md:text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                        importTab === 'photo'
                          ? 'bg-white text-teal-600 shadow-sm'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      </svg>
                      📸 Photo Scan (AI)
                    </button>
                  </div>

                  {/* Notepad Tab */}
                  {importTab === 'notepad' && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="space-y-1">
                        <textarea
                          rows={6}
                          value={notepadText}
                          onChange={(e) => setNotepadText(e.target.value)}
                          placeholder="Paste Notepad notes here"
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold shadow-inner focus:border-teal-400 focus:bg-white text-xs md:text-sm font-mono"
                        />
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                        <div className="flex gap-2">
                          {notepadText && (
                            <button
                              type="button"
                              onClick={() => setNotepadText('')}
                              className="text-[9px] bg-slate-50 hover:bg-slate-100 text-slate-500 font-bold px-3 py-1.5 rounded-lg border border-slate-100 transition-all"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                        <button
                          type="button"
                          disabled={!notepadText.trim()}
                          onClick={handleNotepadParse}
                          className={`px-6 py-2.5 rounded-xl font-black text-[10px] md:text-xs uppercase tracking-widest transition-all shadow-md active:scale-95 flex items-center gap-1.5 ${
                            notepadText.trim()
                              ? 'bg-teal-600 hover:bg-teal-700 text-white shadow-teal-600/10'
                              : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                          }`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" />
                          </svg>
                          Import List
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Photo Scan Tab */}
                  {importTab === 'photo' && (
                    <div className="space-y-6 animate-fade-in py-12 flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 rounded-full bg-amber-50 flex items-center justify-center text-amber-500 shadow-sm animate-pulse">
                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                      </div>
                      <div className="space-y-2 max-w-sm px-4">
                        <h3 className="text-base md:text-lg font-black text-slate-800 uppercase tracking-wider">
                          This Service Is Temporary Unavailable
                        </h3>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-relaxed">
                          We are performing system maintenance. Please check back later or use the Notepad Text tab above.
                        </p>
                      </div>
                    </div>
                  )}
                  {false && importTab === 'photo' && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-teal-400 rounded-2xl p-6 transition-all bg-slate-50/50 relative overflow-hidden group">
                        {selectedImage ? (
                          <div className="relative w-full max-w-sm rounded-xl overflow-hidden shadow-md group">
                            <img
                              src={selectedImage}
                              alt="Scanned note"
                              referrerPolicy="no-referrer"
                              className="w-full object-contain max-h-64 bg-slate-100"
                            />
                            {/* Glowing Laser Scan Effect */}
                            {isScanning && (
                              <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-teal-400 via-emerald-400 to-teal-400 shadow-[0_0_12px_#2dd4bf] scanner-laser-line" />
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedImage(null);
                                setScanResults([]);
                                setScanError(null);
                              }}
                              className="absolute top-2 right-2 p-1.5 bg-red-600/80 hover:bg-red-700 text-white rounded-full transition-all shadow-md active:scale-95"
                            >
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </button>
                          </div>
                        ) : (
                          <div className="text-center space-y-3">
                            <div className="w-12 h-12 rounded-full bg-teal-50 flex items-center justify-center text-teal-600 mx-auto shadow-sm group-hover:scale-110 transition-transform">
                              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                              </svg>
                            </div>
                            <div>
                              <p className="text-xs font-black text-slate-700 uppercase tracking-widest">Select or Snap Photo</p>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Upload Handwriting or Screenshot Here</p>
                            </div>
                            <div className="flex flex-wrap gap-3 justify-center">
                              <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-[10px] md:text-xs uppercase tracking-widest cursor-pointer shadow-sm transition-all active:scale-95">
                                📷 Camera
                                <input
                                  type="file"
                                  accept="image/*"
                                  capture="environment"
                                  onChange={handleImageChange}
                                  className="hidden"
                                />
                              </label>
                              <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-700 hover:bg-slate-800 text-white rounded-xl font-bold text-[10px] md:text-xs uppercase tracking-widest cursor-pointer shadow-sm transition-all active:scale-95">
                                🖼️ Gallery
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={handleImageChange}
                                  className="hidden"
                                />
                              </label>
                            </div>
                          </div>
                        )}
                      </div>

                      {selectedImage && !isScanning && scanResults.length === 0 && (
                        <div className="flex justify-center">
                          <button
                            type="button"
                            onClick={handlePhotoScan}
                            className="px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-black text-[10px] md:text-xs uppercase tracking-widest transition-all shadow-md active:scale-95 flex items-center gap-2"
                          >
                            🚀 Start AI Scan
                          </button>
                        </div>
                      )}

                      {isScanning && (
                        <div className="flex flex-col items-center justify-center py-4 space-y-2 text-center animate-pulse">
                          <div className="w-8 h-8 rounded-full border-4 border-teal-500 border-t-transparent animate-spin" />
                          <p className="text-[10px] font-black text-teal-600 uppercase tracking-widest">Scanning Photo</p>
                        </div>
                      )}

                      {/* API Server URL Settings Toggle */}
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                          className="flex items-center gap-1.5 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-teal-600 transition-all ml-auto"
                        >
                          ⚙️ {isSettingsOpen ? 'Hide API Settings' : 'Show API Settings'}
                        </button>
                        
                        {isSettingsOpen && (
                          <div className="mt-2 p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 animate-fade-in text-left">
                            <label className="block text-[9px] font-black uppercase tracking-widest text-slate-500">
                              Backend API Server URL (Capacitor/Native App)
                            </label>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                value={customApiUrl}
                                onChange={(e) => setCustomApiUrl(e.target.value)}
                                placeholder="https://ais-pre-...asia-east1.run.app"
                                className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-600 focus:outline-none focus:border-teal-500 shadow-sm"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  if (typeof window !== 'undefined') {
                                    setCustomApiUrl(window.location.origin);
                                    alert('Server URL reset to current window origin.');
                                  }
                                }}
                                className="px-2.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all"
                              >
                                Auto Detect
                              </button>
                            </div>
                            <p className="text-[9px] text-slate-400 leading-normal">
                              💡 <strong>Note:</strong> If you get "Failed to fetch" on your native app, please verify that this matches the live Shared App URL or Dev App URL shown in AI Studio!
                            </p>

                            <div className="border-t border-slate-200 my-2 pt-2">
                              <label className="block text-[9px] font-black uppercase tracking-widest text-slate-500">
                                Optional: Personal Gemini API Key (Direct Bypass Scan)
                              </label>
                              <div className="flex gap-2 mt-1">
                                <input
                                  type="password"
                                  value={customGeminiApiKey}
                                  onChange={(e) => setCustomGeminiApiKey(e.target.value)}
                                  placeholder="AIzaSy..."
                                  className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-600 focus:outline-none focus:border-teal-500 shadow-sm"
                                />
                                {customGeminiApiKey && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setCustomGeminiApiKey('');
                                      alert('Personal Gemini API Key cleared.');
                                    }}
                                    className="px-2.5 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all"
                                  >
                                    Clear
                                  </button>
                                )}
                              </div>
                              <p className="text-[9px] text-slate-400 leading-normal mt-1">
                                💡 <strong>Direct Bypass:</strong> Enter your own personal Gemini API Key here to run scans **100% client-side** directly on your device. This completely bypasses any workspace server URL, firewall, or Google Cloud Login redirection issues!
                              </p>
                            </div>
                          </div>
                        )}
                      </div>

                      {scanError && (
                        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl text-red-800 text-xs font-medium animate-fade-in space-y-2">
                          <div className="flex items-center gap-2 font-black text-red-700 uppercase tracking-wider text-[10px]">
                            <span>⚠️ Error Occurred</span>
                          </div>
                          {scanError.includes("API key not valid") || scanError.includes("API_KEY_INVALID") || scanError.includes("API key") ? (
                            <div className="space-y-2">
                              <p className="font-black text-[11px] text-red-800 uppercase tracking-wider">Gemini API Key is Missing or Invalid</p>
                              <p className="text-slate-700 font-bold leading-relaxed">
                                আপনার Gemini API Key সেট করা নেই অথবা অকার্যকর (Invalid)!
                              </p>
                              <p className="text-slate-600 leading-relaxed">
                                AI ফটো স্ক্যানার ব্যবহার করার জন্য আপনার <strong className="text-red-700">GEMINI_API_KEY</strong> সেট করতে হবে। 
                                এটি সেট করতে AI Studio এর ডানদিকের <strong>Settings (গিয়ার আইকন)</strong> বা <strong>Secrets</strong> প্যানেল থেকে আপনার Gemini API Key-টি যুক্ত করুন।
                              </p>
                              <div className="p-2.5 bg-white/60 rounded-xl border border-red-100 text-[10px] text-slate-500 font-normal leading-normal">
                                Your Gemini API Key is missing or invalid. Please configure the <strong className="text-slate-700 font-bold">GEMINI_API_KEY</strong> secret in the Settings/Secrets panel of the AI Studio workspace to activate the scanner.
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-2">
                              <p className="font-bold">{scanError}</p>
                              <p className="text-[10px] text-slate-600">
                                💡 Connection issue? Make sure the <strong>API Server URL</strong> in the "⚙️ Show API Settings" above matches the current URL of your active AI Studio workspace.
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      {scanResults.length > 0 && (
                        <div className="space-y-4 animate-fade-in text-left">
                          <div className="bg-teal-50/40 p-3 border border-teal-100 rounded-xl flex items-center justify-between text-teal-800 text-[10px] font-bold">
                            <span>✅ SCAN COMPLETED! You can edit, delete, or insert missing items directly.</span>
                            <span className="text-slate-500">Total: {scanResults.length} Items</span>
                          </div>

                          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-inner max-h-96 overflow-y-auto">
                            <table className="w-full border-collapse text-left text-xs bg-slate-50/50">
                              <thead>
                                <tr className="bg-slate-100 border-b border-slate-200">
                                  <th className="p-2 font-black text-slate-600 uppercase tracking-wider text-center w-12">No.</th>
                                  <th className="p-2 font-black text-slate-600 uppercase tracking-wider">Height</th>
                                  <th className="p-2 font-black text-slate-600 uppercase tracking-wider">Length 1</th>
                                  <th className="p-2 font-black text-slate-600 uppercase tracking-wider">Length 2</th>
                                  <th className="p-2 font-black text-slate-600 uppercase tracking-wider text-center w-20">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                {scanResults.map((item, idx) => (
                                  <React.Fragment key={idx}>
                                    {/* Inline Hoverable Insert Bar */}
                                    {idx > 0 && (
                                      <tr>
                                        <td colSpan={5} className="p-0 text-center relative h-1.5 group/sep">
                                          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex items-center justify-center opacity-0 group-hover/sep:opacity-100 transition-opacity z-10">
                                            <button
                                              type="button"
                                              onClick={() => insertScanResultAt(idx)}
                                              className="px-2.5 py-0.5 bg-teal-500 hover:bg-teal-600 text-white rounded-full text-[9px] font-black uppercase tracking-widest shadow-md transition-all active:scale-95"
                                            >
                                              + Insert Item Here (Item {idx + 1})
                                            </button>
                                          </div>
                                          <div className="h-0.5 border-t border-dashed border-slate-200 w-full group-hover/sep:border-teal-400"></div>
                                        </td>
                                      </tr>
                                    )}
                                    <tr className="border-b border-slate-100 bg-white hover:bg-teal-50/5">
                                      <td className="p-2 text-center font-bold text-slate-400">{idx + 1}</td>
                                      <td className="p-1">
                                        <input
                                          type="text"
                                          value={item.height}
                                          onChange={(e) => updateScanResult(idx, 'height', e.target.value)}
                                          className="w-full px-2 py-1 border border-slate-200 rounded-lg font-bold text-teal-600 bg-white focus:outline-none focus:border-teal-500 shadow-sm"
                                          placeholder="Height"
                                        />
                                      </td>
                                      <td className="p-1">
                                        <input
                                          type="text"
                                          value={item.length1}
                                          onChange={(e) => updateScanResult(idx, 'length1', e.target.value)}
                                          className="w-full px-2 py-1 border border-slate-200 rounded-lg font-bold text-slate-700 bg-white focus:outline-none focus:border-teal-500 shadow-sm"
                                          placeholder="Length 1"
                                        />
                                      </td>
                                      <td className="p-1">
                                        <input
                                          type="text"
                                          value={item.length2}
                                          onChange={(e) => updateScanResult(idx, 'length2', e.target.value)}
                                          className="w-full px-2 py-1 border border-slate-200 rounded-lg font-bold text-slate-700 bg-white focus:outline-none focus:border-teal-500 shadow-sm"
                                          placeholder="Length 2"
                                        />
                                      </td>
                                      <td className="p-1 text-center">
                                        <div className="flex items-center justify-center gap-1.5">
                                          <button
                                            type="button"
                                            onClick={() => insertScanResultAt(idx)}
                                            className="p-1.5 text-teal-600 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition-all active:scale-95"
                                            title="Insert Blank Row Above"
                                          >
                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" />
                                            </svg>
                                          </button>
                                          <button
                                            type="button"
                                            onClick={() => removeScanResult(idx)}
                                            className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all active:scale-95"
                                            title="Delete Item"
                                          >
                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                          </button>
                                        </div>
                                      </td>
                                    </tr>
                                  </React.Fragment>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                            <button
                              type="button"
                              onClick={addScanResultAtEnd}
                              className="px-3.5 py-2 border border-dashed border-teal-300 hover:border-teal-500 text-teal-600 hover:bg-teal-50/50 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5"
                            >
                              <span>➕ Add Item at End</span>
                            </button>
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest hidden sm:inline">
                              💡 Tip: Hover between rows to insert items in middle
                            </span>
                          </div>

                          <div className="flex justify-end gap-3 pt-2">
                            <button
                              type="button"
                              onClick={() => {
                                setScanResults([]);
                                setSelectedImage(null);
                              }}
                              className="px-4 py-2.5 text-[10px] md:text-xs font-black uppercase tracking-widest text-slate-500 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
                            >
                              Scan Again
                            </button>
                            <button
                              type="button"
                              onClick={handleImportScanResults}
                              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-black text-[10px] md:text-xs uppercase tracking-widest transition-all shadow-md flex items-center gap-2 active:scale-95"
                            >
                              Import Scanned Data ({scanResults.length})
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>

            {sets.map((set, index) => {
              const hVal = parseFloat(set.height) || 0;
              const l1Val = parseFloat(set.length1) || 0;
              const qualifiesPartition = (hVal > 0 && l1Val > 0) && (set.isInchMode ? (hVal >= SIX_FEET_IN && l1Val >= FOUR_FEET_IN) : (hVal >= SIX_FEET_CM && l1Val >= FOUR_FEET_CM));
              const qualifiesShutter = (hVal > 0 && l1Val > 0) && (hVal >= FIVE_FEET_CM && l1Val < FORTY_TWO_IN_CM || hVal >= FIVE_FEET_IN && l1Val < FORTY_TWO_IN);
              const qualifiesFan = !set.isInchMode && hVal > 0 && l1Val > 0 && hVal < 61 && l1Val < 61;

              return (
                <div key={set.id} className={`relative p-4 md:p-6 border rounded-2xl md:rounded-[2rem] group transition-all hover:shadow-lg ${qualifiesPartition ? 'bg-emerald-50/30 border-emerald-200' : 'bg-slate-50/20 border-slate-100 hover:border-teal-100'}`}>
                  <div className="flex items-center justify-between mb-4 md:mb-6">
                    <div className="flex flex-wrap items-center gap-2 md:gap-3">
                      <span className="px-3 md:px-4 py-1.5 bg-slate-900 text-white text-[9px] md:text-[10px] font-black uppercase tracking-widest rounded-lg md:rounded-xl shadow-lg shadow-slate-900/10">Item {index + 1}</span>
                      {qualifiesFan && (
                        <button onClick={() => updateSet(set.id, 'isOverridden', !set.isOverridden)} className={`px-3 md:px-4 py-1.5 text-[9px] md:text-[10px] font-black uppercase tracking-widest rounded-lg md:rounded-xl transition-all border ${!set.isOverridden ? 'bg-amber-600 border-amber-500 text-white shadow-md' : 'bg-white border-slate-200 text-slate-400'}`}>Fan Light</button>
                      )}
                      {qualifiesPartition && (
                        <div className="px-3 md:px-4 py-1.5 bg-emerald-600 border border-emerald-500 text-white text-[9px] md:text-[10px] font-black uppercase tracking-widest rounded-lg md:rounded-xl flex items-center gap-1.5 md:gap-2 cursor-default select-none shadow-md shadow-emerald-600/20">
                          <span className="w-1.5 md:w-2 h-1.5 md:h-2 bg-emerald-200 rounded-full animate-pulse"></span>Partition
                        </div>
                      )}
                      {qualifiesShutter && !qualifiesPartition && (
                        <div className="flex items-center gap-2">
                          <button onClick={() => updateSet(set.id, 'isShutterOverridden', !set.isShutterOverridden)} className={`px-3 md:px-4 py-1.5 text-[9px] md:text-[10px] font-black uppercase tracking-widest rounded-lg transition-all border ${!set.isShutterOverridden ? 'bg-indigo-600 border-indigo-500 text-white shadow-md' : 'bg-white border-slate-200 text-slate-400'}`}>1 Shutter</button>
                        </div>
                      )}
                    </div>
                    {sets.length > 1 && (
                      <button onClick={() => removeSet(set.id)} className="p-1.5 md:p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg md:rounded-xl transition-all">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2 md:gap-6">
                    <div className="space-y-1 md:space-y-2">
                      <label className="text-[7px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest ml-0.5 truncate block">Height ({set.isInchMode ? 'INCH' : 'CM'})</label>
                      <input type="number" inputMode="decimal" value={set.height} onChange={(e) => updateSet(set.id, 'height', e.target.value)} className="w-full px-2 md:px-5 py-3 md:py-4 bg-white border rounded-lg md:rounded-2xl outline-none font-bold shadow-inner focus:border-teal-400 text-xs md:text-base" placeholder="0.0" />
                    </div>
                    <div className="space-y-1 md:space-y-2">
                      <label className="text-[7px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest ml-0.5 truncate block">Length 1</label>
                      <input type="number" inputMode="decimal" value={set.length1} onChange={(e) => updateSet(set.id, 'length1', e.target.value)} className="w-full px-2 md:px-5 py-3 md:py-4 bg-white border rounded-lg md:rounded-2xl outline-none font-bold shadow-inner focus:border-teal-400 text-xs md:text-base" placeholder="0.0" />
                    </div>
                    <div className="space-y-1 md:space-y-2">
                      <label className="text-[7px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest ml-0.5 truncate block">Length 2</label>
                      <input type="number" inputMode="decimal" value={set.length2} onChange={(e) => updateSet(set.id, 'length2', e.target.value)} className="w-full px-2 md:px-5 py-3 md:py-4 bg-white border rounded-lg md:rounded-2xl outline-none font-bold shadow-inner focus:border-teal-400 text-xs md:text-base" placeholder="Opt" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-4 md:p-8 bg-slate-50 border-t border-slate-200 space-y-3 md:space-y-4">
            <button onClick={addSet} className="w-full flex items-center justify-center gap-2 md:gap-3 px-4 md:px-8 py-4 md:py-5 bg-white text-slate-600 border border-dashed border-slate-300 rounded-xl md:rounded-[1.5rem] font-black hover:border-teal-400 hover:text-teal-600 transition-all shadow-sm uppercase tracking-widest text-[10px] md:text-xs">
              <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 4v16m8-8H4" /></svg>Add Item
            </button>

            {/* Customer Details Accordion */}
            <div className="bg-white border border-slate-200 rounded-xl md:rounded-[1.5rem] shadow-sm overflow-hidden transition-all duration-300">
              <button
                type="button"
                onClick={() => setIsCustomerDetailsOpen(!isCustomerDetailsOpen)}
                className="w-full flex items-center justify-between px-4 md:px-6 py-4 bg-slate-100/60 hover:bg-slate-100 transition-all font-black text-[10px] md:text-xs text-slate-700 uppercase tracking-widest"
              >
                <div className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                  <span>Customer Details</span>
                </div>
                <svg
                  className={`w-4 h-4 text-slate-500 transition-transform duration-300 ${isCustomerDetailsOpen ? 'rotate-180' : ''}`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isCustomerDetailsOpen && (
                <div className="p-4 md:p-6 space-y-4 border-t border-slate-100 bg-white">
                  {/* Inputs */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Customer Name</label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold shadow-inner focus:border-teal-400 focus:bg-white text-xs md:text-sm"
                        placeholder=""
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Customer Phone Number</label>
                      <input
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold shadow-inner focus:border-teal-400 focus:bg-white text-xs md:text-sm"
                        placeholder=""
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Customer / Site Location</label>
                      <input
                        type="text"
                        value={customerLocation}
                        onChange={(e) => setCustomerLocation(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none font-bold shadow-inner focus:border-teal-400 focus:bg-white text-xs md:text-sm"
                        placeholder=""
                      />
                    </div>
                  </div>

                  {/* Select Triggers */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Aluminum Color</label>
                      <button
                        type="button"
                        onClick={() => setActiveSelectType('alumColor')}
                        className="w-full text-left px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs md:text-sm text-slate-800 hover:border-teal-400 hover:bg-teal-50/10 transition-all flex justify-between items-center"
                      >
                        <span className={`truncate ${!alumColor ? 'text-slate-400 font-medium' : 'text-slate-800'}`}>
                          {alumColor || 'Select Color'}
                        </span>
                        <svg className="w-4 h-4 text-slate-400 flex-shrink-0 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Aluminum Brand</label>
                      <button
                        type="button"
                        onClick={() => setActiveSelectType('alumBrand')}
                        className="w-full text-left px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs md:text-sm text-slate-800 hover:border-teal-400 hover:bg-teal-50/10 transition-all flex justify-between items-center"
                      >
                        <span className={`truncate ${!alumBrand ? 'text-slate-400 font-medium' : 'text-slate-800'}`}>
                          {alumBrand || 'Select Brand'}
                        </span>
                        <svg className="w-4 h-4 text-slate-400 flex-shrink-0 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Glass Type</label>
                      <button
                        type="button"
                        onClick={() => setActiveSelectType('glassType')}
                        className="w-full text-left px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs md:text-sm text-slate-800 hover:border-teal-400 hover:bg-teal-50/10 transition-all flex justify-between items-center"
                      >
                        <span className={`truncate ${!glassType ? 'text-slate-400 font-medium' : 'text-slate-800'}`}>
                          {glassType || 'Select Type'}
                        </span>
                        <svg className="w-4 h-4 text-slate-400 flex-shrink-0 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[8px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest block">Glass Thickness</label>
                      <button
                        type="button"
                        onClick={() => setActiveSelectType('glassThickness')}
                        className="w-full text-left px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs md:text-sm text-slate-800 hover:border-teal-400 hover:bg-teal-50/10 transition-all flex justify-between items-center"
                      >
                        <span className={`truncate ${!glassThickness ? 'text-slate-400 font-medium' : 'text-slate-800'}`}>
                          {glassThickness || 'Select Thickness'}
                        </span>
                        <svg className="w-4 h-4 text-slate-400 flex-shrink-0 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                    </div>
                  </div>

                  {/* Others Brand Input */}
                  {alumBrand === 'Others' && (
                    <div className="pt-2 max-w-md animate-fade-in">
                      <label className="text-[8px] md:text-[10px] font-black text-amber-600 uppercase tracking-widest block mb-1">Specify Other Brand</label>
                      <input
                        type="text"
                        value={otherAlumBrand}
                        onChange={(e) => setOtherAlumBrand(e.target.value)}
                        className="w-full px-4 py-3 bg-amber-50/30 border border-amber-200 rounded-xl outline-none font-bold focus:border-amber-500 focus:bg-white text-xs md:text-sm text-slate-800"
                        placeholder="Type Brand Name"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>


            <button onClick={calculate} className="w-full bg-slate-900 text-cyan-400 font-black py-5 md:py-6 rounded-xl md:rounded-[1.5rem] shadow-2xl hover:bg-slate-800 transition-all tracking-widest text-xs md:text-sm flex items-center justify-center gap-2 group">
              GENERATE LIST <svg className="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
            </button>
          </div>
        </div>
      </div>

      <div id="results-section" ref={resultsRef} className="w-full pt-4 px-3 md:px-0">
        {resultsList.length > 0 ? (
          <div className="space-y-6 md:space-y-10">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between px-2 gap-4">
              <div className="flex items-center gap-3 md:gap-4">
                <div className="w-1 md:w-1.5 h-8 md:h-10 bg-teal-500 rounded-full"></div>
                <div>
                  <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight leading-none">Output</h2>
                  <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Fabrication Ready</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-8">
              {resultsList.map((res, index) => {
                const isPart = !!res.isPartition;
                const cardBgClass = res.isSmallFrame ? 'bg-amber-50 border-amber-200' : res.isOneShutter ? 'bg-indigo-50 border-indigo-200' : isPart ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200';
                const headerBgClass = res.isSmallFrame ? 'bg-amber-600' : res.isOneShutter ? 'bg-indigo-600' : isPart ? 'bg-emerald-600' : 'bg-slate-900';
                const unitLabel = res.isInchMode ? 'INCH' : 'CM';
                const accentColor = res.isSmallFrame ? 'amber' : res.isOneShutter ? 'indigo' : isPart ? 'emerald' : 'teal';

                return (
                  <div key={res.id} className={`rounded-[1.5rem] md:rounded-[2.5rem] shadow-xl border overflow-hidden transition-all hover:scale-[1.01] ${cardBgClass}`}>
                    <div className={`flex items-center justify-between px-4 md:px-8 py-3 md:py-5 text-white ${headerBgClass}`}>
                      <span className="text-[10px] md:text-xs font-black tracking-widest uppercase">ITEM {index + 1} — {res.label}</span>
                      <span className="text-[8px] md:text-[10px] px-2 md:px-3 py-0.5 md:py-1 rounded-lg border text-white font-black bg-black/20 border-white/10 tracking-widest uppercase">{unitLabel}</span>
                    </div>
                    
                    <div className="p-4 md:p-8">
                      <div className="mb-6 md:mb-10">
                        <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                          <span className={`w-1 md:w-1.5 h-4 md:h-5 rounded-full bg-${accentColor}-500`}></span>
                          <h4 className={`text-[10px] md:text-xs font-black uppercase tracking-[0.15em] text-${accentColor}-600`}>Frame Components</h4>
                        </div>
                        <div className="grid grid-cols-2 gap-2 md:gap-4 items-stretch">
                          <ResultTile label="Outer Side" value={res.outerSide} unit={unitLabel} accent={accentColor} />
                          {res.outerTop === res.outerBottom ? (
                            <ResultTile label="Outer T/B" value={res.outerTop} unit={unitLabel} accent={accentColor} />
                          ) : (
                            <div className="grid grid-cols-1 gap-2 col-span-1">
                              <ResultTile label="Outer Top" value={res.outerTop} unit={unitLabel} accent={accentColor} />
                              <ResultTile label="Outer Bottom" value={res.outerBottom} unit={unitLabel} accent={accentColor} />
                            </div>
                          )}
                          <ResultTile label={res.isOneShutter ? "Lock" : "S/I Lock"} value={res.lockVal} unit={unitLabel} accent={accentColor} />
                          <ResultTile label="Shutter T/B" value={res.shutterTopBottom} unit={unitLabel} accent={accentColor} />
                          
                          {thaiSize !== '3' && !res.isOneShutter && res.netSectionHeight && (
                            <ResultTile label="N/S Height" value={res.netSectionHeight} unit={unitLabel} accent="emerald" />
                          )}
                          {thaiSize !== '3' && !res.isOneShutter && res.netSectionLength && (
                            <ResultTile label="N/S Length" value={res.netSectionLength} unit={unitLabel} accent="emerald" />
                          )}
                        </div>
                      </div>

                      <div className={`pt-6 md:pt-8 border-t border-dashed border-${accentColor}-200/50`}>
                        <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                          <span className={`w-1 md:w-1.5 h-4 md:h-5 rounded-full bg-${accentColor}-500`}></span>
                          <h4 className={`text-[10px] md:text-xs font-black uppercase tracking-[0.15em] text-${accentColor}-600`}>Glass (INCH)</h4>
                        </div>
                        <div className="grid grid-cols-2 gap-2 md:gap-4">
                          <ResultTile label="Glass Height" value={res.glassHeightInch} unit="Inch" accent={accentColor} />
                          <ResultTile label="Glass Length" value={res.glassLengthInch} unit="Inch" accent={accentColor} />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 md:py-24 text-center bg-white/50 border border-dashed border-slate-200 rounded-[2rem] md:rounded-[3rem]">
            <div className="w-16 h-16 md:w-24 md:h-24 bg-white rounded-2xl shadow-xl flex items-center justify-center mb-6 md:mb-8 text-slate-200 ring-4 ring-slate-50">
              <svg className="w-8 h-8 md:w-12 md:h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <h3 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight">Thai Ready</h3>
            <p className="text-slate-500 text-[11px] md:text-sm mt-2 md:mt-4 font-medium uppercase tracking-widest opacity-60">Input measurements above</p>
          </div>
        )}
      </div>

      {/* Dynamic Pop-up Selection Modal */}
      {activeSelectType && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-sm transition-all animate-fade-in">
          <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col animate-slide-up">
            {/* Modal Header */}
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-sm md:text-base font-black text-slate-800 uppercase tracking-wider">
                  {activeSelectType === 'alumColor' && 'Select Aluminum Color'}
                  {activeSelectType === 'alumBrand' && 'Select Aluminum Brand'}
                  {activeSelectType === 'glassType' && 'Select Glass Type'}
                  {activeSelectType === 'glassThickness' && 'Select Glass Thickness'}
                </h3>
                <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Tap an option to select</p>
              </div>
              <button
                onClick={() => setActiveSelectType(null)}
                className="p-1.5 hover:bg-slate-200 rounded-full text-slate-400 hover:text-slate-700 transition-all"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Modal Options List */}
            <div className="p-6 overflow-y-auto space-y-2.5">
              {activeSelectType === 'alumColor' &&
                ALUM_COLORS.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setAlumColor(opt);
                      setActiveSelectType(null);
                    }}
                    className={`w-full text-left px-5 py-4 rounded-xl font-bold text-xs md:text-sm border transition-all flex items-center justify-between ${
                      alumColor === opt
                        ? 'bg-teal-600 text-white border-teal-600 shadow-md shadow-teal-600/10'
                        : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100/70 hover:border-slate-200'
                    }`}
                  >
                    <span>{opt}</span>
                    {alumColor === opt && (
                      <svg className="w-4.5 h-4.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}

              {activeSelectType === 'alumBrand' &&
                ALUM_BRANDS.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setAlumBrand(opt);
                      setActiveSelectType(null);
                    }}
                    className={`w-full text-left px-5 py-4 rounded-xl font-bold text-xs md:text-sm border transition-all flex items-center justify-between ${
                      alumBrand === opt
                        ? 'bg-teal-600 text-white border-teal-600 shadow-md shadow-teal-600/10'
                        : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100/70 hover:border-slate-200'
                    }`}
                  >
                    <span>{opt}</span>
                    {alumBrand === opt && (
                      <svg className="w-4.5 h-4.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}

              {activeSelectType === 'glassType' &&
                GLASS_TYPES.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setGlassType(opt);
                      setActiveSelectType(null);
                    }}
                    className={`w-full text-left px-5 py-4 rounded-xl font-bold text-xs md:text-sm border transition-all flex items-center justify-between ${
                      glassType === opt
                        ? 'bg-teal-600 text-white border-teal-600 shadow-md shadow-teal-600/10'
                        : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100/70 hover:border-slate-200'
                    }`}
                  >
                    <span>{opt}</span>
                    {glassType === opt && (
                      <svg className="w-4.5 h-4.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}

              {activeSelectType === 'glassThickness' &&
                (glassType === 'Clear Glass' ? ['5 MM', '6 MM'] : ['5 MM', '5.5 MM', '6 MM']).map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setGlassThickness(opt);
                      setActiveSelectType(null);
                    }}
                    className={`w-full text-left px-5 py-4 rounded-xl font-bold text-xs md:text-sm border transition-all flex items-center justify-between ${
                      glassThickness === opt
                        ? 'bg-teal-600 text-white border-teal-600 shadow-md shadow-teal-600/10'
                        : 'bg-slate-50 border-slate-100 text-slate-700 hover:bg-slate-100/70 hover:border-slate-200'
                    }`}
                  >
                    <span>{opt}</span>
                    {glassThickness === opt && (
                      <svg className="w-4.5 h-4.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
            </div>
          </div>
        </div>
      )}

      <HistoryModal isOpen={isHistoryOpen} onClose={() => setIsHistoryOpen(false)} history={history} onRestore={restoreFromHistory} onDelete={(id) => setHistory(history.filter(h => h.id !== id))} onClearAll={() => setHistory([])} />

      {(resultsList.length > 0 || sets.some(s => s.height || s.length1)) && (
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-8 px-4">
          {resultsList.length > 0 && (
            <button 
              onClick={handleSaveAsImage} 
              disabled={isSaving}
              className={`flex items-center gap-2 md:gap-3 px-6 md:px-10 py-3 md:py-4 ${isSaving ? 'bg-slate-400' : 'bg-gradient-to-br from-teal-500 to-teal-700 hover:from-teal-600 hover:to-teal-800'} text-white rounded-xl md:rounded-[1.5rem] font-black transition-all shadow-xl shadow-teal-500/20 uppercase tracking-widest text-[10px] md:text-xs active:scale-95`}
            >
              {isSaving ? "Saving..." : "Save Report to Gallery"}
            </button>
          )}
          <button onClick={clearAll} className="flex items-center gap-2 md:gap-3 px-6 md:px-10 py-3 md:py-4 bg-white text-red-500 border border-red-100 rounded-xl md:rounded-[1.5rem] font-black hover:bg-red-50 transition-all shadow-xl uppercase tracking-widest text-[10px] md:text-xs active:scale-95">
            Clear Data
          </button>
        </div>
      )}
    </div>
  );
};

const ResultTile: React.FC<{ label: string; value: string; unit?: string; accent: string }> = ({ label, value, unit = "CM", accent }) => {
  const accentBorderMap: Record<string, string> = { amber: 'hover:border-amber-400', indigo: 'hover:border-indigo-400', emerald: 'hover:border-emerald-400', teal: 'hover:border-teal-400' };
  const accentBorder = accentBorderMap[accent] || 'hover:border-teal-400';
  return (
    <div className={`p-3 md:p-5 rounded-xl md:rounded-2xl border transition-all bg-white border-slate-100 text-slate-800 ${accentBorder} group shadow-sm flex flex-col justify-center h-full`}>
      <p className="text-[8px] md:text-[9px] font-black mb-0.5 md:mb-1.5 uppercase tracking-[0.15em] text-slate-400 group-hover:text-slate-500 transition-colors">{label}</p>
      <div className="flex items-baseline gap-1 md:gap-2">
        <p className="text-lg md:text-2xl font-black leading-none tracking-tight">{value}</p>
        <span className="text-[8px] md:text-[10px] font-black opacity-30 tracking-widest">{unit}</span>
      </div>
    </div>
  );
};

export default Calculator;
