import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LayoutGrid, ChevronLeft, LogOut } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { HUB_CONFIG } from '@/src/hub-config';

interface LayoutProps {
  children: React.ReactNode;
  activeService: 'app1' | 'app2';
  onSwitch: (service: 'app1' | 'app2') => void;
  onExit: () => void;
}

export default function Layout({ children, activeService, onSwitch, onExit }: LayoutProps) {
  return (
    <div className="flex flex-col h-screen bg-slate-50 overflow-hidden pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)]">
      {/* Optimized Sticky Navigation Bar */}
      <header className="sticky top-0 z-50 flex items-center justify-between px-4 md:px-8 py-3.5 bg-white/95 backdrop-blur-md border-b border-slate-100 shrink-0">
        {/* Left: Brand Icon & Title */}
        <div className="flex items-center gap-2">
          <img 
            src="/logo.png?v=2" 
            alt="Logo" 
            className="w-7 h-7 md:w-8 md:h-8 rounded-lg shadow-sm border border-slate-100" 
            referrerPolicy="no-referrer" 
          />
          <span className="font-black text-slate-800 text-[11px] md:text-sm tracking-wider uppercase">Thai Fabricator</span>
        </div>

        {/* Right: Simplified Text Tabs */}
        <div className="flex items-center gap-6 md:gap-8">
          <button
            onClick={() => onSwitch('app1')}
            className={cn(
              "text-sm md:text-base font-bold uppercase tracking-wider transition-all duration-200 active:scale-95",
              activeService === 'app1' 
                ? "text-slate-900 scale-105 border-b-2 border-slate-900 pb-0.5" 
                : "text-slate-400 hover:text-slate-600"
            )}
          >
            Thai
          </button>

          <button
            onClick={() => onSwitch('app2')}
            className={cn(
              "text-sm md:text-base font-bold uppercase tracking-wider transition-all duration-200 active:scale-95",
              activeService === 'app2' 
                ? "text-slate-900 scale-105 border-b-2 border-slate-900 pb-0.5" 
                : "text-slate-400 hover:text-slate-600"
            )}
          >
            Base-8
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 relative overflow-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeService}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="h-full"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
