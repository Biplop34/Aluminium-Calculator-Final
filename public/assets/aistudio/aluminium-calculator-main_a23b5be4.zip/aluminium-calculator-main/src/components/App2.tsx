/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Delete, RotateCcw, Equal, Plus, Minus, X, Divide, Info } from 'lucide-react';

// Logic for Base-8 Point Math
// A number X.Y is treated as X wholes and Y parts (where 8 parts = 1 whole)
const toParts = (val: string): number => {
  if (!val || val === '.') return 0;
  const [wholeStr, partStr] = val.split('.');
  const wholes = parseInt(wholeStr || '0', 10);
  const parts = parseInt(partStr || '0', 10);
  return wholes * 8 + parts;
};

const fromParts = (totalParts: number): string => {
  const isNegative = totalParts < 0;
  const absoluteParts = Math.abs(totalParts);
  const wholes = Math.floor(absoluteParts / 8);
  const parts = absoluteParts % 8;
  return `${isNegative ? '-' : ''}${wholes}.${parts}`;
};

interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  resultValue: number;
}

export default function App() {
  const [display, setDisplay] = useState('0');
  const [prevValue, setPrevValue] = useState<number | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('app2_history');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });
  const [expression, setExpression] = useState('');
  const historyRef = React.useRef<HTMLDivElement>(null);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('app2_history', JSON.stringify(history));
  }, [history]);

  // Auto-scroll to bottom of history when it changes
  useEffect(() => {
    if (historyRef.current) {
      const container = historyRef.current;
      // Use requestAnimationFrame to ensure the DOM has updated with the new item
      requestAnimationFrame(() => {
        container.scrollTop = container.scrollHeight;
      });
    }
  }, [history]);

  const [lastClearClick, setLastClearClick] = useState(0);

  const handleDigit = (digit: string) => {
    if (waitingForOperand) {
      if (!operator) setExpression('');
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  };

  const handleDot = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
      return;
    }
    if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleClear = () => {
    const now = Date.now();
    if (now - lastClearClick < 500) {
      // Double tap - Full Reset (including history)
      setHistory([]);
      setLastClearClick(0);
    } else {
      // Single tap - Current Calculation Reset
      setDisplay('0');
      setPrevValue(null);
      setOperator(null);
      setWaitingForOperand(false);
      setExpression('');
      setLastClearClick(now);
    }
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  };

  const calculate = (op: string, a: number, b: number): number => {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '*': return Math.round((a * b) / 8);
      case '/': return b === 0 ? 0 : Math.round((a * 8) / b);
      default: return b;
    }
  };

  const handleOperator = (nextOperator: string) => {
    const inputValue = toParts(display);

    // If already waiting for an operand, just update the operator and return
    if (waitingForOperand && operator) {
      setOperator(nextOperator);
      return;
    }

    if (prevValue === null) {
      setPrevValue(inputValue);
      setExpression(display);
    } else if (operator) {
      const result = calculate(operator, prevValue, inputValue);
      setPrevValue(result);
      setExpression(prev => `${prev} ${operator} ${display}`);
      setDisplay(fromParts(result));
    }

    setWaitingForOperand(true);
    setOperator(nextOperator);
  };

  const handleEquals = () => {
    const inputValue = toParts(display);
    if (operator && prevValue !== null) {
      const result = calculate(operator, prevValue, inputValue);
      const resultStr = fromParts(result);
      const fullExpression = `${expression} ${operator} ${display}`;
      
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        expression: fullExpression,
        result: resultStr,
        resultValue: result
      };
      
      setHistory(prev => {
        const newHistory = [...prev, newHistoryItem];
        return newHistory.slice(-20);
      });
      setDisplay(resultStr);
      setPrevValue(null);
      setOperator(null);
      setExpression(fullExpression);
      setWaitingForOperand(true);
    }
  };

  const handleRestoreHistory = (item: HistoryItem) => {
    setDisplay(item.result);
    setPrevValue(item.resultValue);
    setExpression(item.expression);
    setOperator(null);
    setWaitingForOperand(true);
  };

  // Live preview calculation
  const getLiveResult = () => {
    if (prevValue === null || !operator) return null;
    
    // Hide live result if we just pressed the first operator and haven't typed the second number
    if (waitingForOperand && expression === display) return null;

    // If waiting for the next number in a chain, show the accumulated total
    if (waitingForOperand) return fromParts(prevValue);
    
    const result = calculate(operator, prevValue, toParts(display));
    return fromParts(result);
  };

  // Auto-normalize if user types something like 0.8
  useEffect(() => {
    const [whole, part] = display.split('.');
    if (part && parseInt(part, 10) >= 8) {
      const total = toParts(display);
      setDisplay(fromParts(total));
    }
  }, [display]);

  return (
    <div className="h-full w-full bg-white text-slate-900 flex flex-col overflow-hidden font-sans">
      <div className="flex-1 bg-white flex flex-col overflow-hidden">
        
        {/* Display Area */}
        <div className="px-6 py-6 bg-white flex flex-col flex-1 justify-end overflow-hidden">
          {/* History List (Top Section) */}
          <div 
            ref={historyRef}
            className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-2.5 mb-6 border-b border-slate-100 pb-4 scroll-smooth"
          >
            <AnimatePresence initial={false} mode="popLayout">
              {history.length === 0 ? (
                <div className="text-slate-300 text-xs italic text-right py-2">No history</div>
              ) : (
                history.map((item) => (
                  <motion.button
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    onClick={() => handleRestoreHistory(item)}
                    className="text-slate-400 hover:text-orange-500/80 text-base transition-all text-right w-full py-1 shrink-0 flex flex-col items-end"
                  >
                    <span className="opacity-80 text-xs break-all leading-tight text-slate-400 font-medium">{item.expression}</span>
                    <div className="flex items-center gap-1">
                      <span className="opacity-60 text-xs text-slate-300">=</span>
                      <span className="font-bold text-slate-600">{item.result}</span>
                    </div>
                  </motion.button>
                ))
              )}
            </AnimatePresence>
          </div>

          {/* Current Calculation (Bottom Section) */}
          <div className="w-full flex flex-col items-end">
            <AnimatePresence mode="popLayout">
              <motion.div 
                key={expression || 'empty'}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-slate-400 text-sm md:text-base mb-1 min-h-[1.5rem] text-right w-full break-all font-medium"
              >
                {expression} {operator}
              </motion.div>
            </AnimatePresence>
            
            <motion.div 
              key={display}
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-6xl md:text-7xl font-light tracking-tighter break-all text-right w-full leading-none py-2 text-slate-900"
            >
              {display}
            </motion.div>

            {/* Result Preview */}
            <div className="h-8 flex items-center justify-end w-full">
              {getLiveResult() && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-orange-500 text-lg md:text-xl font-black flex items-center gap-2"
                >
                  <span className="text-xs uppercase tracking-widest text-slate-400 font-bold">Result:</span>
                  = {getLiveResult()}
                </motion.div>
              )}
            </div>
          </div>
        </div>

        {/* Keypad */}
        <div className="p-5 grid grid-cols-4 gap-3 bg-slate-50 border-t border-slate-100 pb-12 shadow-[0_-8px_30px_rgb(0,0,0,0.02)]">
          {/* Row 1 */}
          <CalcButton label="AC" onClick={handleClear} variant="operator" />
          <CalcButton label={<Delete size={20} />} onClick={handleBackspace} variant="operator" />
          <CalcButton label={<Divide size={20} />} onClick={() => handleOperator('/')} active={operator === '/'} variant="operator" />
          <CalcButton label={<X size={20} />} onClick={() => handleOperator('*')} active={operator === '*'} variant="operator" />

          {/* Row 2 */}
          <CalcButton label="7" onClick={() => handleDigit('7')} />
          <CalcButton label="8" onClick={() => handleDigit('8')} />
          <CalcButton label="9" onClick={() => handleDigit('9')} />
          <CalcButton label={<Minus size={20} />} onClick={() => handleOperator('-')} active={operator === '-'} variant="operator" />

          {/* Row 3 */}
          <CalcButton label="4" onClick={() => handleDigit('4')} />
          <CalcButton label="5" onClick={() => handleDigit('5')} />
          <CalcButton label="6" onClick={() => handleDigit('6')} />
          <CalcButton label={<Plus size={20} />} onClick={() => handleOperator('+')} active={operator === '+'} variant="operator" />

          {/* Row 4 */}
          <CalcButton label="1" onClick={() => handleDigit('1')} />
          <CalcButton label="2" onClick={() => handleDigit('2')} />
          <CalcButton label="3" onClick={() => handleDigit('3')} />
          <CalcButton 
            label={<Equal size={24} />} 
            onClick={handleEquals} 
            variant="accent" 
            className="row-span-2 h-full" 
          />

          {/* Row 5 */}
          <CalcButton label="0" onClick={() => handleDigit('0')} className="col-span-2" />
          <CalcButton label="." onClick={handleDot} />
        </div>
      </div>
    </div>
  );
}

interface CalcButtonProps {
  label: React.ReactNode;
  onClick: () => void;
  variant?: 'default' | 'operator' | 'accent';
  className?: string;
  active?: boolean;
}

function CalcButton({ label, onClick, variant = 'default', className = '', active = false }: CalcButtonProps) {
  const variants = {
    default: 'bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-800 border border-slate-100 shadow-sm shadow-slate-100/50',
    operator: active 
      ? 'bg-orange-100 text-orange-600 border border-orange-200 shadow-inner font-bold' 
      : 'bg-white hover:bg-orange-50/30 active:bg-orange-50 text-orange-500 border border-slate-100 shadow-sm shadow-slate-100/50 font-bold',
    accent: 'bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white shadow-md shadow-orange-500/20 font-black',
  };

  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        h-16 rounded-2xl flex items-center justify-center text-xl font-bold transition-all duration-150
        ${variants[variant]}
        ${className}
      `}
    >
      {label}
    </motion.button>
  );
}

