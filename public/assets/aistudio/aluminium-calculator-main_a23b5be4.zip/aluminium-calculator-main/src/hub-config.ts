/**
 * AI HUB CONFIGURATION
 * 
 * Edit this file to customize your apps' names, icons, and descriptions.
 */
import { Sparkles, Image as ImageIcon } from 'lucide-react';

export const HUB_CONFIG = {
  // Set to 'app1' or 'app2' to skip the selection screen on startup
  // Set to null to always show the selection screen
  DEFAULT_APP: 'app2' as 'app1' | 'app2' | null,

  app1: {
    id: 'app1' as const,
    name: 'Thai Fabrication Tool',
    description: 'Professional calculator for Thai fabrication measurements and glass specs.',
    icon: Sparkles,
    color: 'blue',
  },
  app2: {
    id: 'app2' as const,
    name: 'Base-8 Math Lab',
    description: 'Specialized calculator for base-8 point math operations.',
    icon: ImageIcon,
    color: 'purple',
  }
};
